<?php
define('N3N', 1);
include('config.php');
include('functions.php');

global $key_tologin;
if (!CheckGuest($key_tologin))
    NotFound();

$file = $_GET['file'];
$name = urlencode($_GET['name']);
$dir = isset($_GET['dir']) ? $_GET['dir'] : 'files';

if($dir != 'files' and $dir != 'logs') {
    NotFound();
}

if (!get_magic_quotes_gpc())
    $file = stripslashes($file);

$file = str_replace('/', '', $file);
$file = str_replace('.', '', $file);
$file = './files/' . str_replace('../', '', $file);

if (!is_file($file))
    NotFound();
else {
    header('Content-Type: application/octet-stream');
    header('Accept-Ranges: bytes');
    header('Content-Length: ' . filesize($file));
    header('Content-Disposition: attachment; filename=' . $name);
    readfile($file);
}