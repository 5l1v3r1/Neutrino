<?php
define('N3N', 1);
include('config.php');
include('functions.php');

global $key_tologin;
if (!CheckGuest($key_tologin))
    NotFound();

$url = htmlspecialchars($_GET['url']);
header('Refresh: 0; url=' . $url);
?>
<html>
<head>
    <title>Redirecting...</title>
    <meta http-equiv="refresh" content="0;url=<?php echo $url; ?>">
</head>
<body>
Attempting to redirect to <a href="<?php echo $url; ?>"><?php echo $url; ?></a>.
</body>
</html>