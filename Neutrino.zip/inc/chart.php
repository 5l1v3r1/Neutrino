<?php
if (!defined('N3N')) {
    include_once './../config.php';
}
global $country_array;

$client_map_list = null;
$client_map_result = $mysqli->query('SELECT DISTINCT client_country, COUNT(*) AS count FROM ' . DB_CLIENTS . ' GROUP BY client_country ORDER BY count DESC');
while ($row = $client_map_result->fetch_array()) {
    $client_map_list .= '[\'' . $country_array[$row['client_country']] . '\',' . $row['count'] . '],' . PHP_EOL;
}

$client_os_list = null;
$client_os_result = $mysqli->query("SELECT DISTINCT client_os, COUNT(*) AS count FROM " . DB_CLIENTS . " GROUP BY client_os ORDER BY count DESC");
while ($row = $client_os_result->fetch_array()) {
    $client_os_list .= '[\'' . urldecode($row['client_os']) . '\', ' . $row['count'] . '],' . PHP_EOL;
}

$client_cn_list = null;
$client_cn_result = $mysqli->query("SELECT client_country, COUNT(*) AS count FROM " . DB_CLIENTS . " WHERE client_date >= CURDATE() GROUP BY client_country ORDER BY count DESC LIMIT 10");
while ($row = $client_cn_result->fetch_array()) {
    $client_cn_list .= '[\'' . $country_array[$row['client_country']] . '\',' . $row['count'] . '],' . PHP_EOL;
}

$client_top_country = null;
$client_top_result = $mysqli->query("SELECT client_country, COUNT(*) AS count FROM " . DB_CLIENTS . " WHERE client_date >= CURDATE() GROUP BY client_country ORDER BY count DESC LIMIT 10");
while ($row = $client_top_result->fetch_array()) {
    $client_top_country .= '[\'' . $country_array[$row['client_country']] . '\',' . $row['count'] . '],' . PHP_EOL;
}


?>
    <script type="text/javascript" src="//www.gstatic.com/charts/loader.js"></script>
<script>

    google.charts.load('current', {
        'packages': ['table', 'corechart'],
    });

    google.charts.setOnLoadCallback(drawTopCoutry);
    function drawTopCoutry() {
        var data = google.visualization.arrayToDataTable([
            ['Top 10 country', 'Count'],
            <?php echo $client_top_country; ?>
        ]);
        var options = {
            title: 'Top 10 country',
            titleTextStyle: {color: '#fcfcfc'},
            legendTextStyle: {color: '#fcfcfc'},
            pieSliceBorderColor: 'gray',
            backgroundColor: {
                fill: 'transparent'
            },
            chartArea: {
                width: '100%',
                height: '80%'
            }
        };
        var chart = new google.visualization.PieChart(document.getElementById('div_top_statistics'));
        chart.draw(data, options);
    }

    google.charts.setOnLoadCallback(drawOS);
    function drawOS() {
        var data = google.visualization.arrayToDataTable([
            ['OS', 'Count'],
            <?php echo $client_os_list; ?>
        ]);
        var options = {
            title: 'OS Statistics',
            titleTextStyle: {color: '#fcfcfc'},
            legendTextStyle: {color: '#fcfcfc'},
            pieSliceBorderColor: 'gray',
            backgroundColor: {
                fill: 'transparent',
            },
            chartArea: {
                width: '80%',
                height: '80%'
            }
        };
        var chart = new google.visualization.PieChart(document.getElementById('div_os_statistics'));
        chart.draw(data, options);
    }
    google.charts.setOnLoadCallback(CountryMap);
    function CountryMap() {
        var data = google.visualization.arrayToDataTable([
            ['Country', 'Clients'],
            <?php echo $client_map_list; ?>
        ]);
        var options = {
            titleTextStyle: {color: 'white'},
            legendTextStyle: {color: 'white'},
            sizeAxis: {minValue: 0, maxValue: 100},
            backgroundColor: 'transparent',
            colorAxis: {colors: ['#54C492', '#cc0000'], textStyle: {color: 'white'}},
            width: '100%',
            datalessRegionColor: '#dedede'
        };
        var chart = new google.visualization.GeoChart(document.getElementById('div_geo_map'));
        chart.draw(data, options);
    }
</script>

