<?php
if(!defined('N3N')) {
    include_once './../config.php';
}