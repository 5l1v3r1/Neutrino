<?php
if (!defined('N3N')) {
    include_once './../config.php';
}

if (isset($_POST['login'])) {

    $mysqli = new mysqli($db_host, $db_login, base64_decode($db_password), $db_database);
    if ($mysqli->connect_error) {
        die('Connection error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    }

    $data = $mysqli->query('SELECT client_id, client_password FROM ' . DB_USERS . ' WHERE client_username = "' . $mysqli->real_escape_string($_POST['username']) . '" LIMIT 1')->fetch_assoc();
    if ($data['client_password'] === (md5($_POST['password']))) {

        $hash = md5(md5(mt_rand() . microtime()));
        $mysqli->query('UPDATE ' . DB_USERS . ' SET client_hash= "' . $hash . '" WHERE client_id = "' . $data['client_id'] . '"');
        $mysqli->close();

        setcookie('client_id', $data['client_id'], time() + 60 * 60 * 24 * 30);
        setcookie('hash', $hash, time() + 60 * 60 * 24 * 30);

        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
        exit();

    } else {
        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
        exit();
    }
}

if (isset($_COOKIE['client_id']) and isset($_COOKIE['hash'])) {

    $mysqli = new mysqli($db_host, $db_login, base64_decode($db_password), $db_database);
    $sql_query = $mysqli->query('SELECT * FROM ' . DB_USERS . ' WHERE client_id = "' . $mysqli->real_escape_string($_COOKIE['client_id']) . '" LIMIT 1')->fetch_array();
    $mysqli->close();
    if ($sql_query) {
        if (($sql_query['client_hash'] != $_COOKIE['hash']) or ($sql_query['client_id'] != $_COOKIE['client_id'])) {
            setcookie('client_id', '', time() - 1);
            unset($_COOKIE['client_id']);

            setcookie('hash', '', time() - 1);
            unset($_COOKIE['hash']);
            header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
            exit();
        }
    }


} else {
    session_start();
    if (!isset($_SESSION['csrf'])) {
        $_SESSION['csrf'] = md5(md5(mt_rand() . microtime()));
    }
    ?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <head xmlns="http://www.w3.org/1999/html">
        <title></title>

        <link rel='stylesheet' href='./css/bootstrap.min.css'>
        <link rel='stylesheet' href='./css/custom.css'>
        <link rel='stylesheet' href='./css/datepicker.css'>

        <script type='text/javascript' src='./js/jquery-1.12.0.min.js'></script>
        <script type='text/javascript' src='./js/bootstrap.min.js'></script>

        <script type='text/javascript' src='./js/md5.js'></script>
        <script type="text/javascript">
            function calculate_md5() {
                var plain_pwd = document.auth.password.value;
                var hash_pwd = hex_md5(plain_pwd);
                document.auth.password.value = hash_pwd;
            }
        </script>
		<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
        <style>
            body {
                font-family: 'Roboto', sans-serif;
            }
        </style>
    </head>
    <body>
    <br>
    <div class="panel panel-primary" style="width: 30%;margin: 0 auto; text-align: center">
        <div class="panel-body">
            <form name="auth" method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input type="text" id="user" class="form-control" name="username" placeholder="Username">
                </div>
                <p></p>
                <div class="input-group">
                    <span class="input-group-addon"> <i class="glyphicon glyphicon glyphicon-lock"></i></span>
                    <input type="password" id="pass" class="form-control" name="password" autocomplete="off"
                           placeholder="Password">
                </div>
                <p></p>
                <button type="submit" name="login" onclick="calculate_md5()" class="btn btn-primary btn-sm"
                        style="width: 100%">Sign in
                </button>
                <input name="csrf" type="hidden" value="<?php echo $_SESSION['csrf'] ?>">
            </form>
        </div>
    </div>
    </body>
    <?php
    exit();
}
