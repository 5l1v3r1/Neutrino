<?php
if (!defined('N3N')) {
    include_once './config.php';
}

function generateCode($length = 6)
{
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPRQSTUVWXYZ0123456789';
    $code = null;
    $clen = strlen($chars) - 1;
    while (strlen($code) < $length) {
        $code .= $chars[mt_rand(0, $clen)];
    }
    return $code;
}

if (isset($_POST['login'])) {

    $mysqli = new mysqli($db_host, $db_login, $db_password, $db_database);
    $data = $mysqli->query("SELECT uid, password FROM users WHERE username='" . $mysqli->real_escape_string($_POST['username']) . "' LIMIT 1")->fetch_assoc();

    if ($data['password'] === (md5($_POST['password']))) {
        $hash = md5(generateCode(10));
        $mysqli->query("UPDATE users SET hash='" . $hash . "' WHERE uid='" . $data['uid'] . "'");
        $mysqli->close();

        setcookie('uid', $data['uid'], time() + 60 * 60 * 24 * 30);
        setcookie('hash', $hash, time() + 60 * 60 * 24 * 30);

        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
        exit();
    } else {
        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
        exit();
    }
}

if (isset($_COOKIE['uid']) and isset($_COOKIE['hash'])) {
    $mysqli = new mysqli($db_host, $db_login, $db_password, $db_database);
    $query = $mysqli->query("SELECT * FROM users WHERE uid = '" . $mysqli->real_escape_string($_COOKIE['uid']) . "' LIMIT 1")->fetch_array();
    $mysqli->close();

    if (($query['hash'] != $_COOKIE['hash']) or ($query['uid'] != $_COOKIE['uid'])) {
        setcookie('uid', '', time() - 1);
        unset($_COOKIE['uid']);

        setcookie('hash', '', time() - 1);
        unset($_COOKIE['hash']);
        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
        exit();
    }
} else {
    session_start();
    if (!isset($_SESSION['csrf'])) {
        $_SESSION['csrf'] = md5(md5(mt_rand() . microtime()));
    }
    ?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <head xmlns="http://www.w3.org/1999/html">
        <title></title>
        <script type='text/javascript' src='//code.jquery.com/jquery-1.12.0.min.js'></script>
        <link rel="stylesheet" href='//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css'>
        <link rel="stylesheet" href='//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css'>
        <link rel='stylesheet' href='./css/custom.css'>

        <script type='text/javascript' src='//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'></script>
        <script type='text/javascript' src='./js/md5.js'></script>
        <script type="text/javascript">
            function pwd_hash() {
                var plain_pwd = document.auth.password.value;
                var hash_pwd = hex_md5(plain_pwd);
                document.auth.password.value = hash_pwd;
            }
        </script>
    </head>
    <body>
    <div class="panel panel-primary" style="width: 20%;margin: 0 auto; text-align: center">
        <div class="panel-body">
            <form name="auth" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input type="text" id="user" class="form-control" name="username" placeholder="Username">
                </div>
                <p></p>
                <div class="input-group">
                    <span class="input-group-addon"> <i class="glyphicon glyphicon glyphicon-lock"></i></span>
                    <input type="password" id="pass" class="form-control" name="password" autocomplete="off"
                           placeholder="Password">
                </div>
                <p></p>
                <button type="submit" name="login" onclick="pwd_hash()" class="btn btn-info" style="width: 100%">Sign
                    in
                </button>
                <input name="csrf" type="hidden" value="<?php echo $_SESSION['csrf'] ?>">
            </form>
        </div>
    </div>
    </body>
    <?php
    exit();
}
