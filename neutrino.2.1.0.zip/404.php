<?php
if(!defined('N3N')) {
    include_once __DIR__ .  '/config.php';
}